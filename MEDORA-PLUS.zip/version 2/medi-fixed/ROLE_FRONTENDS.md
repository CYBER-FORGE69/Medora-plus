# Medi+ Command — Separate Role Frontends

The frontend is split into independent HTML entry points:

- `frontend/index.html` — Login / registration / SOS
- `frontend/admin.html` — Hospital Admin
- `frontend/doctor.html` — Doctor
- `frontend/nurse.html` — Nurse
- `frontend/patient.html` — Patient

All role pages use the same `frontend/app.js` and `frontend/common.css`.
They communicate through the same Express/REST backend and Socket.IO real-time
channel. Changes made by one role are persisted in the shared database and
broadcast to the other connected role pages.

## Run

From `backend`:

```text
npm.cmd install
npm.cmd start
```

Open:

```text
http://localhost:4000/
```

Direct role pages:

```text
http://localhost:4000/admin.html
http://localhost:4000/doctor.html
http://localhost:4000/nurse.html
http://localhost:4000/patient.html
```

Do not open the HTML files directly with `file://`; run them through the backend
so API requests and real-time Socket.IO communication work.
