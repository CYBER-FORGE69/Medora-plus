# Medi+ Command — Android App (build instructions)

This folder wraps the existing frontend in a real Android app shell using
**Capacitor**. The web UI is unchanged — the app is just a native container
that loads it and talks to your backend over WiFi.

I couldn't compile the `.apk` inside this sandbox (no internet access, no
Android SDK here), so these are the exact commands to run **on your own
computer** to produce it. You'll need:
- Node.js 18+ (you already have this if you ran the backend)
- [Android Studio](https://developer.android.com/studio) installed (it bundles the Android SDK)
- Your phone and computer on the **same WiFi network**

## 0. One-time setup — point the app at your backend

The app can't use `localhost` — that means "the phone itself" on a phone,
not your computer. Edit **`www/config.js`** and set your computer's LAN IP:

```js
window.MEDIPLUS_API_HOST = 'http://192.168.1.100:4000'; // <- your computer's IP
```

Find your IP:
- **Windows:** Command Prompt → `ipconfig` → "IPv4 Address"
- **Mac:** Terminal → `ipconfig getifaddr en0`
- **Linux:** Terminal → `hostname -I`

Your backend must be running (`npm start` in `../backend`) whenever you use
the app, and your phone must stay on the same WiFi network.

## 1. Install the Capacitor tooling

From inside this `mobile/` folder:
```
npm install
```

## 2. Generate the native Android project

```
npx cap add android
```
This creates an `android/` folder with a full native project — you only
need to do this once.

## 3. Allow the app to reach your backend over plain HTTP

Android blocks unencrypted (`http://`) network calls by default. Since your
backend runs on plain HTTP on your LAN, open:
```
android/app/src/main/AndroidManifest.xml
```
and add `android:usesCleartextTraffic="true"` to the `<application ...>` tag,
so it looks like:
```xml
<application
    android:usesCleartextTraffic="true"
    ... (leave everything else as-is) ...>
```

## 4. Sync your web files into the native project

Every time you change anything in `www/` (including `config.js`), run:
```
npx cap sync android
```

## 5. Build and install the APK

**Easiest — via Android Studio:**
```
npx cap open android
```
This opens the project in Android Studio. Then:
- Plug your phone in via USB with USB debugging enabled (or use an emulator), and click the green ▶ Run button — this installs and launches the app directly.
- To get a shareable `.apk` file instead: menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**. When it finishes, click the "locate" link in the notification, or find it at:
  ```
  android/app/build/outputs/apk/debug/app-debug.apk
  ```
  Copy that file to your phone (via USB, email, cloud drive, etc.) and tap it to install. You may need to allow "Install from unknown sources" the first time.

**Command line alternative** (no Android Studio UI):
```
cd android
./gradlew assembleDebug
```
(Windows: `gradlew.bat assembleDebug`). Same output path as above.

## Notes

- This produces a **debug** APK — fine for personal/testing use. For sharing
  publicly or the Play Store, you'd need to generate a signed **release**
  build (Android Studio: Build → Generate Signed Bundle/APK), which needs a
  signing key you create yourself.
- If Google Sign-In doesn't work in the app, add your app's Capacitor origin
  (`https://localhost`) as an Authorized JavaScript origin in Google Cloud
  Console alongside `http://localhost:4000`, or test Google Sign-In in a
  regular mobile browser instead — some OAuth flows behave differently
  inside embedded WebViews.
- If the app can't reach the backend, double-check: backend running, both
  devices on the same WiFi, `config.js` has the right IP, and your
  computer's firewall allows inbound connections on port 4000.
