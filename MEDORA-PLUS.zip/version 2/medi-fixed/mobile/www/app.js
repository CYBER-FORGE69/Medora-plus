// Medi+ split-role application controller
// See config.js: on the packaged Android app, window.MEDIPLUS_API_HOST
// points at the backend's LAN IP instead of localhost.
const BASE_HOST = window.MEDIPLUS_API_HOST || ((window.location.protocol === 'file:' || !window.location.port || window.location.port !== '4000') ? 'http://localhost:4000' : '');
const API = BASE_HOST + '/api';
const PAGE_ROLE = window.MEDI_PLUS_ROLE || '';
let session = null;
let socket = null;
let hospitals = [];
let currentView = 'overview';
let detectedCoords = null;

/* ---------------- Application Core ---------------- */
function toggleSidebar() { document.getElementById('sidebar').classList.toggle('open'); }

function logout() {
  fetch(`${API}/logout`, { method: 'POST', headers: authHeaders() }).catch(()=>{});
  if (socket) socket.disconnect();
  localStorage.removeItem('mediPlusSession');
  session = null;
  window.location.href = 'index.html';
}

function authHeaders() {
  return { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + (session ? session.token : '') };
}

async function api(path, opts = {}) {
  const r = await fetch(API + path, { ...opts, headers: { ...authHeaders(), ...(opts.headers || {}) } });
  if (!r.ok) {
    const e = await r.json().catch(()=>({ error: 'Request failed' }));
    throw new Error(e.error || 'Request failed');
  }
  return r.json();
}

const NAV_ICONS = {
  overview: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>`,
  hospitals: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 21h18"></path><path d="M5 21V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16"></path><line x1="12" y1="7" x2="12" y2="13"></line><line x1="9" y1="10" x2="15" y2="10"></line></svg>`,
  staff: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>`,
  patients: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="4"></circle><path d="M4 21c0-4.4 3.6-8 8-8s8 3.6 8 8"></path></svg>`,
  appointments: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>`,
  blood: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"></path></svg>`,
  organs: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>`,
  ambulances: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg>`,
  diseases: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>`,
  sos: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polygon points="12 6 12 12 16 14"></polygon></svg>`,
  notifications: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>`,
  account: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>`,
  care: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 12h-4l-3 9L9 3l-3 9H2"></path></svg>`,
  equipment: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.24 12.24a6 6 0 0 0-8.49-8.49L5 10.5V19h8.5z"></path><line x1="16" y1="8" x2="2" y2="22"></line><line x1="17.5" y1="15" x2="9" y2="15"></line></svg>`,
  beds: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 4v16"></path><path d="M2 8h18a2 2 0 0 1 2 2v10"></path><path d="M2 17h20"></path><path d="M6 8v9"></path></svg>`,
  profile: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>`,
  report: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>`,
  insurance: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line></svg>`,
  donate: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"></path><line x1="12" y1="11" x2="12" y2="15"></line><line x1="10" y1="13" x2="14" y2="13"></line></svg>`,
  alarms: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="13" r="8"></circle><polyline points="12 9 12 13 15 15"></polyline><path d="M5 3 2 6"></path><path d="M22 6 19 3"></path></svg>`,
  prescriptions: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 2h6v4H9z"></path><path d="M9 6H5a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-4"></path><path d="M9 13h6"></path><path d="M9 17h4"></path></svg>`,
  quicksos: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="13"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>`
};

const NAV = {
  admin: [
    ['overview','Network Overview'],['hospitals','Hospitals'],['staff','Staff Directory'],
    ['patients','Patients'],['appointments','Appointments'],['blood','Blood Availability'],
    ['donations','Blood Donations'],['organs','Organ Donation'],['ambulances','Ambulances'],['diseases','Diseases'],
    ['sos','SOS Alerts'],['notifications','Notifications'],['account','Account Settings']
  ],
  doctor: [
    ['patients','My Patients'],['care','Patient Care & Vitals'],['prescriptions','Prescriptions'],['equipment','Hospital Equipment'],
    ['appointments','Appointments'],['notifications','Notifications'],['account','Account Settings']
  ],
  nurse: [
    ['patients','Patient Records'],['equipment','Equipment Inventory'],['beds','Emergency Readiness'],
    ['blood','Blood Availability'],['donations','Blood Donations'],['alarms','Medicine Alarms'],['organs','Organ Donation'],['appointments','Appointments'],
    ['notifications','Notifications'],['account','Account Settings']
  ],
  patient: [
    ['profile','My Details'],['report','Medical Report'],['care','My Care & Vitals'],['prescriptions','My Prescriptions'],
    ['alarms','Medicine Reminders'],['appointments','My Appointments'],['insurance','Insurance & Cost'],
    ['donate','Donate Blood'],['blood','Blood Availability'],
    ['organs','Organ Donation'],['ambulances','Ambulance Fleet'],['quicksos','Quick SOS'],['notifications','Notifications'],
    ['account','Account Settings']
  ]
};

async function startApp() {
  const user = (session && session.user) ? session.user : {};
  document.getElementById('app').classList.add('on');
  document.getElementById('userName').textContent = user.name || user.id || 'User';
  document.getElementById('userRoleTag').textContent = `${(session.role || '').toUpperCase()} · ${user.id || ''}`;
  const avatarWrap = document.getElementById('userAvatarWrap');
  if (user.photo) avatarWrap.innerHTML = `<img src="${user.photo}" alt="Avatar">`;
  else avatarWrap.innerHTML = `<span>${(user.name || session.role || 'U')[0].toUpperCase()}</span>`;

  try { hospitals = await api('/hospitals'); } catch (e) { hospitals = []; }
  const nav = document.getElementById('navBtns');
  const roleNav = NAV[session.role] || NAV.admin;
  nav.innerHTML = roleNav.map(([k, l]) => `
    <button class="nav-btn" data-v="${k}" onclick="setView('${k}')">
      ${NAV_ICONS[k] || ''}<span>${l}</span>
    </button>
  `).join('');
  setView(roleNav[0][0]);
  connectSocket();
}

function connectSocket() {
  try {
    const socketUrl = BASE_HOST || window.location.origin;
    socket = io(socketUrl);
    socket.on('notification', (n) => {
      toast(`🔔 ${n.message}`);
      if (currentView === 'notifications') renderView();
    });
    ['patients:changed','staff:changed','appointments:changed','equipment:changed','beds:changed','hospitals:changed','blood:changed','organs:changed','sos:changed','health-records:changed','diet:changed','medicines:changed','ambulances:changed','diseases:changed','blood-donations:changed','medicine-alarms:changed','prescriptions:changed']
      .forEach(evt => socket.on(evt, () => renderView()));
    socket.on('sos', (n) => {
      toast(`🚨 SOS ALERT: ${n.name || 'Anonymous'} — ${n.reason || 'Medical emergency'}`);
      if (currentView === 'sos') renderView();
    });
  } catch (e) {}
}

function setView(v) {
  currentView = v;
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.toggle('active', b.dataset.v === v));
  const roleNav = NAV[session.role] || [];
  const navEntry = roleNav.find(x => x[0] === v);
  document.getElementById('viewTitle').textContent = navEntry ? navEntry[1] : 'Dashboard';
  if (window.innerWidth <= 900) document.getElementById('sidebar').classList.remove('open');
  renderView();
}

function toast(msg) {
  const container = document.getElementById('toastContainer');
  const t = document.createElement('div');
  t.className = 'toast';
  t.innerHTML = `<span>${msg}</span>`;
  container.appendChild(t);
  setTimeout(() => {
    t.style.animation = 'toastSlideIn 0.3s reverse forwards';
    setTimeout(() => t.remove(), 300);
  }, 4000);
}

function hospName(id) {
  const h = hospitals.find(x => x.id === id);
  return h ? h.name : (id || '—');
}

/* ---------------- View Renderers ---------------- */
async function renderView() {
  const body = document.getElementById('viewBody');
  try {
    if (currentView === 'overview') return await renderOverview(body);
    if (currentView === 'hospitals') return await renderHospitals(body);
    if (currentView === 'staff') return await renderStaff(body);
    if (currentView === 'patients') return await renderPatients(body);
    if (currentView === 'appointments') return await renderAppointments(body);
    if (currentView === 'notifications') return await renderNotifications(body);
    if (currentView === 'equipment') return await renderEquipment(body);
    if (currentView === 'beds') return await renderBeds(body);
    if (currentView === 'profile') return await renderProfile(body);
    if (currentView === 'report') return await renderReport(body);
    if (currentView === 'insurance') return await renderInsurance(body);
    if (currentView === 'blood') return await renderBlood(body);
    if (currentView === 'organs') return await renderOrgans(body);
    if (currentView === 'care') return await renderCare(body);
    if (currentView === 'ambulances') return await renderAmbulances(body);
    if (currentView === 'diseases') return await renderDiseases(body);
    if (currentView === 'account') return await renderAccount(body);
    if (currentView === 'sos') return await renderSosAlerts(body);
    if (currentView === 'donate') return await renderDonateBlood(body);
    if (currentView === 'donations') return await renderBloodDonations(body);
    if (currentView === 'alarms') return await renderMedicineAlarms(body);
    if (currentView === 'prescriptions') return await renderPrescriptions(body);
    if (currentView === 'quicksos') return await renderQuickSos(body);
  } catch (e) {
    body.innerHTML = `<div class="section"><p style="color:var(--alert)">Failed to load view: ${e.message}</p></div>`;
  }
}

/* OVERVIEW */
async function renderOverview(body) {
  const [patients, beds, equip, ambulances, sosAlerts, donations] = await Promise.all([
    api('/patients').catch(()=>[]),
    api('/beds').catch(()=>[]),
    api('/equipment').catch(()=>[]),
    api('/ambulances').catch(()=>[]),
    api('/sos').catch(()=>[]),
    session.role === 'admin' ? api('/blood-donations').catch(()=>[]) : Promise.resolve([])
  ]);
  const successfulDonations = (donations || []).filter(d => d.status === 'completed').slice(0, 8);
  const occTotal = beds.reduce((a,b)=>a+(b.total||0),0);
  const occUsed = beds.reduce((a,b)=>a+(b.occupied||0),0);
  const occPct = occTotal ? Math.round((occUsed / occTotal) * 100) : 0;
  const criticalPatients = patients.filter(p => p.status === 'critical').length;
  const openSos = (sosAlerts || []).filter(s => s.status === 'open').length;

  body.innerHTML = `
    <div class="grid">
      <div class="card">
        <div class="card-header">
          <h3>Network Hospitals</h3>
          <div class="card-icon">${NAV_ICONS.hospitals}</div>
        </div>
        <div class="big">${hospitals.length}</div>
        <div class="subtext">Active regional medical centers</div>
      </div>

      <div class="card">
        <div class="card-header">
          <h3>Total Patients</h3>
          <div class="card-icon">${NAV_ICONS.patients}</div>
        </div>
        <div class="big">${patients.length}</div>
        <div class="subtext">${criticalPatients} marked as critical status</div>
      </div>

      <div class="card">
        <div class="card-header">
          <h3>Bed Occupancy</h3>
          <div class="card-icon">${NAV_ICONS.beds}</div>
        </div>
        <div class="big">${occUsed} <span style="font-size:16px;color:var(--text-muted)">/ ${occTotal} (${occPct}%)</span></div>
        <div class="progress-bar-wrap">
          <div class="progress-bar-fill" style="width: ${occPct}%; ${occPct>85?'background:var(--alert)':''}"></div>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <h3>Fleet & Equipment</h3>
          <div class="card-icon">${NAV_ICONS.ambulances}</div>
        </div>
        <div class="big">${ambulances.length}</div>
        <div class="subtext">${equip.length} equipment inventory lines</div>
      </div>
    </div>

    ${openSos > 0 ? `
      <div class="section" style="border-color:var(--alert);background:linear-gradient(180deg, var(--card) 0%, rgba(255,71,114,0.08) 100%);">
        <div class="section-head">
          <h2 style="color:var(--alert)"><span class="radar-ring" style="background:var(--alert)"></span> Active Emergency Alerts (${openSos})</h2>
          <button class="btn danger sm" onclick="setView('sos')">View SOS Desk</button>
        </div>
        <p class="section-desc">Critical alerts require immediate dispatch or triage follow-up.</p>
      </div>
    ` : ''}

    ${successfulDonations.length ? `
      <div class="section" style="border-color:var(--teal)">
        <div class="section-head">
          <h2>🩸 Recent Successful Blood Donations (${successfulDonations.length})</h2>
          <button class="btn xs secondary" onclick="setView('donations')">View All</button>
        </div>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Donor Name</th><th>Patient ID</th><th>Blood Group</th><th>Hospital</th><th>Date</th></tr></thead>
            <tbody>
              ${successfulDonations.map(d => `
                <tr>
                  <td><b>${d.fullName}</b></td>
                  <td><span class="tag teal">${d.patientId}</span></td>
                  <td><span class="tag critical">${d.bloodGroup}</span></td>
                  <td>${hospName(d.hospitalId)}</td>
                  <td>${d.appointmentDate}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    ` : ''}

    <div class="section">
      <div class="section-head">
        <h2>Hospital Directory Overview</h2>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr><th>Hospital ID</th><th>Name</th><th>City</th><th>Address</th><th>Status</th></tr>
          </thead>
          <tbody>
            ${hospitals.map(h => `
              <tr>
                <td><span class="tag teal">${h.id}</span></td>
                <td><b>${h.name}</b></td>
                <td>${h.city || '—'}</td>
                <td>${h.address || '—'}</td>
                <td><span class="tag stable">Operational</span></td>
              </tr>
            `).join('') || '<tr><td colspan="5" style="color:var(--text-muted)">No hospitals registered yet.</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

/* HOSPITALS */
async function renderHospitals(body) {
  const patients = await api('/patients').catch(()=>[]);
  const countFor = hid => patients.filter(p => p.hospitalId === hid).length;

  body.innerHTML = `
    <div class="section">
      <h2>Add New Network Hospital</h2>
      <p class="section-desc">Register a new hospital branch with GPS coordinates for ambulance telemetry.</p>
      <form onsubmit="return addHospital(event)">
        <div class="form-row">
          <input id="hName" placeholder="Hospital name *" required>
          <input id="hCity" placeholder="City">
          <input id="hAddress" placeholder="Full address" style="flex:2;">
          <input id="hLat" placeholder="Latitude (e.g. 19.0760)" type="number" step="any" style="max-width:140px">
          <input id="hLng" placeholder="Longitude (e.g. 72.8777)" type="number" step="any" style="max-width:140px">
          <button class="btn xs" type="submit">+ Add Hospital</button>
        </div>
      </form>
    </div>

    <div class="section">
      <div class="section-head">
        <h2>Connected Medical Facilities (${hospitals.length})</h2>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr><th>ID</th><th>Hospital Name</th><th>City</th><th>Address</th><th>GPS Coordinates</th><th>Active Patients</th></tr>
          </thead>
          <tbody>
            ${hospitals.map(h => `
              <tr>
                <td><span class="tag teal">${h.id}</span></td>
                <td><b>${h.name}</b></td>
                <td>${h.city || '—'}</td>
                <td>${h.address || '—'}</td>
                <td>${h.latitude != null && h.longitude != null ? `<a href="https://www.google.com/maps?q=${h.latitude},${h.longitude}" target="_blank" style="color:var(--cyan);text-decoration:none;font-family:var(--font-mono);font-size:11.5px;">📍 ${h.latitude.toFixed(4)}, ${h.longitude.toFixed(4)}</a>` : '—'}</td>
                <td><span class="tag moderate">${countFor(h.id)} patients</span></td>
              </tr>
            `).join('') || '<tr><td colspan="6" style="color:var(--text-muted)">No facilities registered.</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  `;
}
async function addHospital(e) {
  e.preventDefault();
  await api('/hospitals', {
    method: 'POST',
    body: JSON.stringify({
      name: hName.value, city: hCity.value, address: hAddress.value,
      latitude: hLat.value ? +hLat.value : null, longitude: hLng.value ? +hLng.value : null
    })
  });
  hospitals = await api('/hospitals');
  toast('Hospital registered');
  renderView();
  return false;
}

/* STAFF */
async function renderStaff(body) {
  const { doctors = [], nurses = [] } = await api('/staff').catch(()=>({ doctors:[], nurses:[] }));
  const hospOpts = hospitals.map(h => `<option value="${h.id}">${h.name}</option>`).join('');

  body.innerHTML = `
    <div class="section">
      <h2>Register Staff Member</h2>
      <p class="section-desc">Provision Doctor or Nurse medical credentials with assigned hospital facility.</p>
      <form onsubmit="return addStaff(event)">
        <div class="form-row">
          <select id="sRole"><option value="doctor">Doctor</option><option value="nurse">Nurse</option></select>
          <input id="sName" placeholder="Full name *" required>
          <select id="sHosp">${hospOpts}</select>
          <input id="sSpec" placeholder="Specialty (e.g. Cardiology)">
          <input id="sPw" placeholder="Access Password *" required>
          <button class="btn xs" type="submit">+ Add Staff</button>
        </div>
      </form>
    </div>

    <div class="section">
      <div class="section-head">
        <h2>Medical Doctors (${doctors.length})</h2>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>ID</th><th>Doctor Name</th><th>Hospital Facility</th><th>Specialty</th><th>Actions</th></tr></thead>
          <tbody>
            ${doctors.map(d => `
              <tr>
                <td><span class="tag cyan">${d.id}</span></td>
                <td><input class="mini" value="${d.name}" onchange="editStaff('doctor','${d.id}','name',this.value)"></td>
                <td>${hospName(d.hospitalId)}</td>
                <td><input class="mini" value="${d.specialty || ''}" placeholder="Add specialty" onchange="editStaff('doctor','${d.id}','specialty',this.value)"></td>
                <td><button class="btn xs secondary" onclick="removeStaff('doctor','${d.id}')">Remove</button></td>
              </tr>
            `).join('') || '<tr><td colspan="5" style="color:var(--text-muted)">No doctors registered yet.</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>

    <div class="section">
      <div class="section-head">
        <h2>Nursing Staff (${nurses.length})</h2>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>ID</th><th>Nurse Name</th><th>Hospital Facility</th><th>Actions</th></tr></thead>
          <tbody>
            ${nurses.map(n => `
              <tr>
                <td><span class="tag teal">${n.id}</span></td>
                <td><input class="mini" value="${n.name}" onchange="editStaff('nurse','${n.id}','name',this.value)"></td>
                <td>${hospName(n.hospitalId)}</td>
                <td><button class="btn xs secondary" onclick="removeStaff('nurse','${n.id}')">Remove</button></td>
              </tr>
            `).join('') || '<tr><td colspan="4" style="color:var(--text-muted)">No nurses registered yet.</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  `;
}
async function addStaff(e) {
  e.preventDefault();
  const role = sRole.value;
  await api(`/staff/${role}`, {
    method: 'POST',
    body: JSON.stringify({ name: sName.value, hospitalId: sHosp.value, password: sPw.value, specialty: sSpec.value })
  });
  toast('Staff credential generated');
  renderView();
  return false;
}
async function editStaff(role, id, field, value) {
  await api(`/staff/${role}/${id}`, { method: 'PUT', body: JSON.stringify({ [field]: value }) });
  toast('Staff record updated');
}
async function removeStaff(role, id) {
  if (!confirm('Are you sure you want to remove this staff member?')) return;
  await api(`/staff/${role}/${id}`, { method: 'DELETE' });
  toast('Staff removed');
  renderView();
}

/* PATIENTS */
async function renderPatients(body) {
  const patients = await api('/patients').catch(()=>[]);
  const canEditAll = session.role === 'admin';
  let addForm = '';

  if (canEditAll) {
    const { doctors = [] } = await api('/staff').catch(()=>({ doctors:[] }));
    addForm = `
      <div class="section">
        <h2>Admit New Patient</h2>
        <p class="section-desc">Create patient electronic medical record with department & assigned doctor.</p>
        <form onsubmit="return addPatient(event)">
          <div class="form-row">
            <input id="pName" placeholder="Full Name *" required>
            <input id="pAge" placeholder="Age" type="number" style="max-width:90px">
            <select id="pGender"><option value="">Gender</option><option>Male</option><option>Female</option><option>Other</option></select>
            <select id="pBlood"><option value="">Blood Group</option>${['A+','A-','B+','B-','AB+','AB-','O+','O-'].map(g=>`<option>${g}</option>`).join('')}</select>
            <input id="pContact" placeholder="Contact number">
            <input id="pEmergency" placeholder="Emergency contact">
            <input id="pDept" placeholder="Department">
            <select id="pHosp">${hospitals.map(h=>`<option value="${h.id}">${h.name}</option>`).join('')}</select>
            <select id="pDoc">${doctors.map(d=>`<option value="${d.id}">${d.name}</option>`).join('')}</select>
            <input id="pPw" placeholder="Password *" required>
            <button class="btn xs" type="submit">+ Admit Patient</button>
          </div>
        </form>
      </div>
    `;
  }

  body.innerHTML = `
    ${addForm}
    <div class="section">
      <div class="section-head">
        <h2>Patient Directory (${patients.length})</h2>
      </div>

      <div class="filter-bar">
        <div class="search-input-wrap">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
          <input class="search-input" id="patSearch" placeholder="Filter by name, ID, or department..." oninput="filterPatientRows()">
        </div>
      </div>

      <div class="table-wrap">
        <table id="patientTable">
          <thead>
            <tr><th>Patient ID</th><th>Name</th><th>Department</th><th>Status</th><th>Doctor</th><th>Hospital</th>${canEditAll?'<th>Actions</th>':''}</tr>
          </thead>
          <tbody>
            ${patients.map(p => `
              <tr class="patient-row" data-search="${(p.name+' '+p.id+' '+(p.dept||'')).toLowerCase()}">
                <td><span class="tag teal">${p.id}</span></td>
                <td><b>${p.name}</b></td>
                <td>${p.dept || '—'}</td>
                <td>
                  <select class="mini" onchange="editPatient('${p.id}','status',this.value)">
                    <option ${p.status==='stable'?'selected':''} value="stable">🟢 Stable</option>
                    <option ${p.status==='moderate'?'selected':''} value="moderate">🟡 Moderate</option>
                    <option ${p.status==='critical'?'selected':''} value="critical">🔴 Critical</option>
                    <option ${p.status==='discharged'?'selected':''} value="discharged">⚪ Discharged</option>
                  </select>
                </td>
                <td>${p.doctorId || '—'}</td>
                <td>${hospName(p.hospitalId)}</td>
                ${canEditAll ? `
                  <td>
                    <div class="table-actions">
                      <button class="btn xs secondary" onclick="editPatient('${p.id}','status','discharged')">Discharge</button>
                      <button class="btn xs secondary" onclick="removePatient('${p.id}')">Remove</button>
                    </div>
                  </td>
                ` : ''}
              </tr>
            `).join('') || '<tr><td colspan="7" style="color:var(--text-muted)">No patient records available.</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>

    <div class="section">
      <h2>Medical Summary &amp; Clinical Progress Reports</h2>
      <p class="section-desc">${canEditAll ? 'Hospital Admin can update reports; attending doctors and nurses view live updates.' : 'Attending medical reports.'}</p>
      ${patients.map(p => `
        <div class="report-row">
          <div class="report-row-head">
            <div style="display:flex;align-items:center;gap:10px;">
              <b>${p.name}</b>
              <span class="tag ${p.status}">${p.status}</span>
              <span style="color:var(--text-muted);font-size:12px;">ID: ${p.id}</span>
            </div>
          </div>
          ${canEditAll
            ? `<textarea class="report-ta" placeholder="Enter clinical assessment or discharge summary..." onblur="editPatient('${p.id}','report',this.value)">${p.report || ''}</textarea>`
            : `<div class="report-view">${p.report ? p.report.replace(/</g,'&lt;') : 'No clinical summary on file.'}</div>`}
        </div>
      `).join('')}
    </div>
  `;
}
function filterPatientRows() {
  const query = document.getElementById('patSearch').value.toLowerCase();
  document.querySelectorAll('.patient-row').forEach(row => {
    row.style.display = row.dataset.search.includes(query) ? '' : 'none';
  });
}
async function addPatient(e) {
  e.preventDefault();
  await api('/patients', {
    method: 'POST',
    body: JSON.stringify({
      name: pName.value, age: +pAge.value, dept: pDept.value, hospitalId: pHosp.value, doctorId: pDoc.value, password: pPw.value,
      gender: pGender.value, bloodGroup: pBlood.value, contactNumber: pContact.value, emergencyContact: pEmergency.value
    })
  });
  toast('Patient admitted');
  renderView();
  return false;
}
async function editPatient(id, field, value) {
  await api(`/patients/${id}`, { method: 'PUT', body: JSON.stringify({ [field]: value }) });
  toast('Patient updated');
}
async function removePatient(id) {
  if (!confirm('Are you sure you want to remove this patient record?')) return;
  await api(`/patients/${id}`, { method: 'DELETE' });
  toast('Patient removed');
  renderView();
}

/* APPOINTMENTS */
async function renderAppointments(body) {
  const appts = await api('/appointments').catch(()=>[]);
  let form = '';
  if (session.role === 'patient') {
    form = `
      <div class="section">
        <h2>Schedule Consultation Appointment</h2>
        <form onsubmit="return bookAppt(event)">
          <div class="form-row">
            <input id="aDate" type="date" required>
            <input id="aReason" placeholder="Reason for consultation" style="flex:2;">
            <button class="btn xs" type="submit">Request Appointment</button>
          </div>
        </form>
      </div>
    `;
  }
  const canSetStatus = ['admin','doctor','nurse'].includes(session.role);

  body.innerHTML = `
    ${form}
    <div class="section">
      <div class="section-head">
        <h2>Consultations &amp; Appointments (${appts.length})</h2>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr><th>Appt ID</th><th>Patient</th><th>Date</th><th>Reason</th><th>Status</th>${canSetStatus?'<th>Actions</th>':''}</tr>
          </thead>
          <tbody>
            ${appts.map(a => `
              <tr>
                <td><span class="tag teal">${a.id}</span></td>
                <td><b>${a.patientId}</b></td>
                <td>${a.date}</td>
                <td>${a.reason || '—'}</td>
                <td>
                  <span class="tag ${a.status==='confirmed'?'stable':(a.status==='cancelled'?'critical':'moderate')}">
                    ${a.status}
                  </span>
                </td>
                ${canSetStatus ? `
                  <td>
                    <div class="table-actions">
                      <button class="btn xs secondary" onclick="setApptStatus('${a.id}','confirmed')">Confirm</button>
                      <button class="btn xs secondary" onclick="setApptStatus('${a.id}','cancelled')">Cancel</button>
                      ${session.role === 'doctor' ? `<button class="btn xs secondary" onclick="proposeReschedule('${a.id}')">I'm busy — propose new slot</button>` : ''}
                    </div>
                  </td>
                ` : ''}
              </tr>
            `).join('') || `<tr><td colspan="6" style="color:var(--text-muted)">No appointments scheduled.</td></tr>`}
          </tbody>
        </table>
      </div>
    </div>
  `;
}
async function bookAppt(e) {
  e.preventDefault();
  await api('/appointments', {
    method: 'POST',
    body: JSON.stringify({ date: aDate.value, reason: aReason.value, hospitalId: session.user.hospitalId, doctorId: session.user.doctorId })
  });
  toast('Appointment scheduled');
  renderView();
  return false;
}
async function setApptStatus(id, status) {
  await api(`/appointments/${id}`, { method: 'PUT', body: JSON.stringify({ status }) });
  toast(`Appointment ${status}`);
  renderView();
}
// Doctor is busy elsewhere: instead of just cancelling, offer the patient the
// next available date/time. Sets status to "rescheduled".
async function proposeReschedule(id) {
  const date = prompt('Propose a new date for this appointment (YYYY-MM-DD):');
  if (!date) return;
  await api(`/appointments/${id}`, { method: 'PUT', body: JSON.stringify({ date }) });
  toast('New slot proposed — patient notified');
  renderView();
}

/* NOTIFICATIONS */
async function renderNotifications(body) {
  const n = await api('/notifications').catch(()=>[]);
  body.innerHTML = `
    <div class="section">
      <h2>Live System Audit &amp; Event Notifications</h2>
      <p class="section-desc">Broadcast notifications synchronized across hospital personnel.</p>
      ${n.length ? n.map(x => `
        <div class="notif-item">
          <div class="notif-time">${new Date(x.createdAt).toLocaleTimeString()}</div>
          <div style="flex:1;">${x.message}</div>
          <span class="tag ${x.audience==='all'?'teal':'cyan'}">${x.audience}</span>
        </div>
      `).join('') : '<p style="color:var(--text-muted);padding:14px 0;">No new notifications.</p>'}
    </div>
  `;
}

/* EQUIPMENT */
async function renderEquipment(body) {
  const eq = await api('/equipment').catch(()=>[]);
  const canEdit = session.role === 'admin' || session.role === 'nurse';

  body.innerHTML = `
    <div class="section">
      <div class="section-head">
        <h2>Medical Equipment Inventory (${eq.length})</h2>
      </div>
      <p class="section-desc">${canEdit ? 'Hospital Admin and Nursing staff maintain real-time equipment availability.' : 'Real-time equipment availability.'}</p>
      <div class="table-wrap">
        <table>
          <thead>
            <tr><th>Equipment Item</th><th>Facility</th><th>Total Units</th><th>Available Units</th><th>Operational Status</th></tr>
          </thead>
          <tbody>
            ${eq.map(x => `
              <tr>
                <td><b>${x.name}</b></td>
                <td>${hospName(x.hospitalId)}</td>
                <td>
                  ${canEdit ? `<input class="mini" style="width:80px" type="number" value="${x.total}" onchange="editEquip('${x.id}','total',this.value)">` : x.total}
                </td>
                <td>
                  ${canEdit ? `<input class="mini" style="width:80px" type="number" value="${x.available}" onchange="editEquip('${x.id}','available',this.value)">` : x.available}
                </td>
                <td>
                  <span class="tag ${x.available > 0 ? 'stable' : 'critical'}">
                    ${x.available > 0 ? `${x.available} Ready` : 'Depleted'}
                  </span>
                </td>
              </tr>
            `).join('') || '<tr><td colspan="5" style="color:var(--text-muted)">No equipment listed.</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  `;
}
async function editEquip(id, field, value) {
  await api(`/equipment/${id}`, { method: 'PUT', body: JSON.stringify({ [field]: +value }) });
  toast('Inventory updated');
}

/* BEDS */
async function renderBeds(body) {
  const beds = await api('/beds').catch(()=>[]);
  const totalBeds = beds.reduce((a,b)=>a+(b.total||0),0);
  const occupiedBeds = beds.reduce((a,b)=>a+(b.occupied||0),0);
  const freeBeds = totalBeds - occupiedBeds;

  body.innerHTML = `
    <div class="grid">
      <div class="card">
        <h3>Total Capacity</h3>
        <div class="big">${totalBeds}</div>
        <div class="subtext">Registered hospital beds</div>
      </div>
      <div class="card">
        <h3>Occupied Beds</h3>
        <div class="big" style="color:var(--amber)">${occupiedBeds}</div>
        <div class="subtext">Active inpatient count</div>
      </div>
      <div class="card">
        <h3>Immediate Free Beds</h3>
        <div class="big" style="color:var(--green)">${freeBeds}</div>
        <div class="subtext">Emergency admissions ready</div>
      </div>
    </div>

    <div class="section">
      <div class="section-head">
        <h2>Emergency Readiness &mdash; Hospital Bed Grid</h2>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr><th>Hospital Facility</th><th>Total Capacity</th><th>Occupied</th><th>Free Beds</th><th>Availability Bar</th></tr>
          </thead>
          <tbody>
            ${beds.map(b => {
              const free = (b.total||0) - (b.occupied||0);
              const pct = b.total ? Math.round((b.occupied / b.total) * 100) : 0;
              return `
                <tr>
                  <td><b>${hospName(b.hospitalId)}</b></td>
                  <td><input class="mini" style="width:75px" type="number" value="${b.total}" onchange="editBeds('${b.hospitalId}','total',this.value)"></td>
                  <td><input class="mini" style="width:75px" type="number" value="${b.occupied}" onchange="editBeds('${b.hospitalId}','occupied',this.value)"></td>
                  <td><span class="tag ${free > 5 ? 'stable' : (free > 0 ? 'moderate' : 'critical')}">${free} Free</span></td>
                  <td style="min-width:140px;">
                    <div class="progress-bar-wrap" style="margin:0;">
                      <div class="progress-bar-fill" style="width:${pct}%; ${pct>90?'background:var(--alert)':''}"></div>
                    </div>
                  </td>
                </tr>
              `;
            }).join('') || '<tr><td colspan="5" style="color:var(--text-muted)">No bed records found.</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  `;
}
async function editBeds(hospitalId, field, value) {
  await api(`/beds/${hospitalId}`, { method: 'PUT', body: JSON.stringify({ [field]: +value }) });
  toast('Bed readiness updated');
}

/* PATIENT PROFILE */
async function renderProfile(body) {
  const patients = await api('/patients').catch(()=>[]);
  const me = patients[0] || (session && session.user) || {};

  body.innerHTML = `
    <div class="section" style="display:flex;gap:20px;align-items:center;flex-wrap:wrap;">
      ${me.photo ? `<img src="${me.photo}" style="width:72px;height:72px;border-radius:50%;object-fit:cover;border:2px solid var(--teal);">` : `<div style="width:72px;height:72px;border-radius:50%;background:var(--card-alt);border:2px solid var(--teal);display:flex;align-items:center;justify-content:center;font-size:26px;color:var(--teal);">${(me.name||'?')[0]}</div>`}
      <div>
        <h2 style="font-size:22px;margin-bottom:4px;">${me.name || 'Patient'}</h2>
        <div style="color:var(--text-muted);font-size:13px;display:flex;gap:12px;align-items:center;">
          <span class="tag teal">${me.id || ''}</span>
          <span>${hospName(me.hospitalId)}</span>
        </div>
      </div>
    </div>

    <div class="grid">
      <div class="card"><h3>Triage Status</h3><div class="big"><span class="tag ${me.status||'stable'}">${me.status||'stable'}</span></div></div>
      <div class="card"><h3>Department</h3><div class="big" style="font-size:20px">${me.dept || 'General Medicine'}</div></div>
      <div class="card"><h3>Attending Doctor</h3><div class="big" style="font-size:20px">${me.doctorId || 'DR-1001'}</div></div>
      <div class="card"><h3>Blood Group</h3><div class="big" style="font-size:20px;color:var(--alert)">${me.bloodGroup || '—'}</div></div>
      <div class="card"><h3>Age / Gender</h3><div class="big" style="font-size:20px">${me.age || '—'} / ${me.gender || '—'}</div></div>
      <div class="card"><h3>Contact Number</h3><div class="big" style="font-size:18px">${me.contactNumber || me.phone || '—'}</div></div>
      <div class="card"><h3>Emergency Contact</h3><div class="big" style="font-size:16px">${me.emergencyContact || '—'}</div></div>
    </div>

    <div class="section">
      <h2>Primary Diagnosis</h2>
      <p style="font-size:14px;color:var(--text);">${me.diagnosis || 'No active acute diagnosis recorded.'}</p>
    </div>
  `;
}

/* PATIENT REPORT */
async function renderReport(body) {
  const patients = await api('/patients').catch(()=>[]);
  const me = patients[0] || (session && session.user) || {};
  body.innerHTML = `
    <div class="section">
      <h2>Official Medical &amp; Clinical Summary</h2>
      <p class="section-desc">Managed by Hospital Admin &amp; Attending Specialists.</p>
      <div class="report-view" style="font-size:14px;line-height:1.7;">
        ${me.report ? me.report.replace(/</g,'&lt;') : 'No clinical report filed yet.'}
      </div>
    </div>
  `;
}

/* INSURANCE */
async function renderInsurance(body) {
  const patients = await api('/patients').catch(()=>[]);
  const me = patients[0] || (session && session.user) || {};
  body.innerHTML = `
    <div class="grid">
      <div class="card">
        <h3>Insurance Provider</h3>
        <div class="big" style="font-size:22px;">${me.insurance || 'Universal Care (Self-Pay)'}</div>
        <div class="subtext">Policy claim status: Active</div>
      </div>
      <div class="card">
        <h3>Accumulated Treatment Cost</h3>
        <div class="big" style="color:var(--teal)">₹${(me.cost || 0).toLocaleString('en-IN')}</div>
        <div class="subtext">Includes bed, medication, and doctor visits</div>
      </div>
    </div>
  `;
}

/* BLOOD AVAILABILITY */
const BLOOD_LOW = 4;
async function renderBlood(body) {
  const canEdit = session.role === 'admin' || session.role === 'nurse';
  const rows = await api('/blood').catch(()=>[]);
  const grouped = {};
  rows.forEach(r => { (grouped[r.hospitalId] = grouped[r.hospitalId] || []).push(r); });

  body.innerHTML = Object.keys(grouped).map(hid => `
    <div class="section">
      <div class="section-head">
        <h2>${hospName(hid)} &mdash; Blood Bank Stock</h2>
      </div>
      <div class="blood-grid">
        ${grouped[hid].map(b => `
          <div class="blood-card ${b.units <= BLOOD_LOW ? 'low' : ''}">
            <div class="blood-type">${b.bloodGroup}</div>
            <div class="blood-units">${b.units}</div>
            <div style="font-size:11px;color:${b.units<=BLOOD_LOW?'var(--alert)':'var(--text-muted)'};margin-top:2px;">
              ${b.units <= BLOOD_LOW ? '⚠️ Low Stock' : 'Units ready'}
            </div>
            ${canEdit ? `
              <div class="blood-stepper">
                <button class="step-btn" onclick="stepBlood('${b.id}', ${b.units - 1})">-</button>
                <button class="step-btn" onclick="stepBlood('${b.id}', ${b.units + 1})">+</button>
              </div>
            ` : ''}
          </div>
        `).join('')}
      </div>
    </div>
  `).join('') || '<div class="section"><p style="color:var(--text-muted)">No blood bank inventory recorded.</p></div>';
}
async function stepBlood(id, val) {
  if (val < 0) return;
  await api(`/blood/${id}`, { method: 'PUT', body: JSON.stringify({ units: val }) });
  toast('Blood stock adjusted');
}

/* ORGAN DONATION */
async function renderOrgans(body) {
  const canEdit = session.role === 'admin' || session.role === 'nurse';
  const rows = await api('/organs').catch(()=>[]);
  const grouped = {};
  rows.forEach(r => { (grouped[r.hospitalId] = grouped[r.hospitalId] || []).push(r); });

  let donorSection = '';
  if (session.role === 'patient') {
    const isDonor = !!(session.user && session.user.isDonor);
    donorSection = `
      <div class="section" style="border-color:${isDonor?'var(--teal)':'var(--border)'}">
        <h2>Your Organ Donor Pledge</h2>
        <div style="display:flex;align-items:center;gap:14px;margin:12px 0;">
          <span class="tag ${isDonor?'stable':'moderate'}">${isDonor ? '✓ Registered Organ Donor' : 'Not Registered'}</span>
          <button class="btn xs ${isDonor?'secondary':''}" onclick="toggleDonor(${isDonor?'false':'true'})">
            ${isDonor ? 'Withdraw Pledge' : 'Pledge to Donate Organs'}
          </button>
        </div>
        <p class="section-desc">Pledging gives hope to patients on critical waiting lists.</p>
      </div>
    `;
  }

  body.innerHTML = donorSection + Object.keys(grouped).map(hid => `
    <div class="section">
      <h2>${hospName(hid)} &mdash; Organ Requirement Matrix</h2>
      <div class="grid" style="margin-top:14px;">
        ${grouped[hid].map(o => `
          <div class="card">
            <h3>${o.organ}</h3>
            ${canEdit ? `
              <div style="display:flex;gap:8px;margin:8px 0;">
                <div style="flex:1;"><label style="font-size:10px;color:var(--text-muted)">REQUIRED</label><input class="mini" type="number" value="${o.required}" onchange="editOrgan('${o.id}','required',this.value)"></div>
                <div style="flex:1;"><label style="font-size:10px;color:var(--text-muted)">PLEDGED</label><input class="mini" type="number" value="${o.pledged}" onchange="editOrgan('${o.id}','pledged',this.value)"></div>
              </div>
            ` : `
              <div class="big" style="${o.required > o.pledged ? 'color:var(--alert)' : 'color:var(--green)'}">
                ${o.pledged} / ${o.required}
              </div>
            `}
            <div class="subtext">${o.required > o.pledged ? `${o.required - o.pledged} more urgently needed` : 'Requirement fulfilled'}</div>
          </div>
        `).join('')}
      </div>
    </div>
  `).join('');
}
async function editOrgan(id, field, value) {
  await api(`/organs/${id}`, { method: 'PUT', body: JSON.stringify({ [field]: +value }) });
  toast('Organ requirement updated');
}
async function toggleDonor(next) {
  const data = await api(`/patients/${session.user.id}/donor-pledge`, { method: 'PUT', body: JSON.stringify({ isDonor: next }) });
  session.user.isDonor = data.isDonor ? 1 : 0;
  toast(next ? 'Registered as organ donor ❤️' : 'Donor pledge withdrawn');
  renderView();
}

/* SOS ALERTS MONITOR */
async function renderSosAlerts(body) {
  const alerts = await api('/sos').catch(()=>[]);
  body.innerHTML = `
    <div class="section">
      <div class="section-head">
        <h2>Emergency SOS Command Center (${alerts.length})</h2>
      </div>
      <p class="section-desc">Live emergency signals received from public distress requests.</p>
      ${alerts.length ? `
        <div class="table-wrap">
          <table>
            <thead>
              <tr><th>Timestamp</th><th>Caller Name</th><th>Contact Number</th><th>Emergency Description</th><th>Nearest Hospital</th><th>Coordinates</th><th>Triage Status</th><th>Action</th></tr>
            </thead>
            <tbody>
              ${alerts.map(a => `
                <tr>
                  <td>${new Date(a.createdAt).toLocaleTimeString()}</td>
                  <td><b>${a.name || 'Anonymous'}</b></td>
                  <td><a href="tel:${a.phone}" style="color:var(--teal);text-decoration:none;font-weight:700;">📞 ${a.phone}</a></td>
                  <td>${a.reason || '—'}</td>
                  <td>${a.hospitalId ? hospName(a.hospitalId) : '—'}</td>
                  <td>
                    ${a.latitude != null && a.longitude != null ? `
                      <a href="https://www.google.com/maps?q=${a.latitude},${a.longitude}" target="_blank" style="color:var(--cyan);text-decoration:none;font-family:var(--font-mono);font-size:11.5px;">📍 Map Link</a>
                    ` : '—'}
                  </td>
                  <td><span class="tag ${a.status==='open'?'critical':'stable'}">${a.status}</span></td>
                  <td>
                    ${a.status === 'open' ? `<button class="btn xs secondary" onclick="resolveSos('${a.id}')">Resolve Alert</button>` : '—'}
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      ` : '<p style="color:var(--text-muted);padding:14px 0;">No active emergency distress signals.</p>'}
    </div>
  `;
}
async function resolveSos(id) {
  await api(`/sos/${id}`, { method: 'PUT', body: JSON.stringify({ status: 'resolved' }) });
  toast('SOS alert marked resolved');
  renderView();
}

/* PATIENT CARE & CLINICAL VITALS */
async function renderCare(body) {
  if (session.role === 'doctor') return await renderCareDoctor(body);
  return await renderCarePatient(body);
}
async function renderCareDoctor(body) {
  const patients = await api('/patients').catch(()=>[]);
  if (!patients.length) {
    body.innerHTML = `<div class="section"><p style="color:var(--text-muted)">No patients assigned to your care.</p></div>`;
    return;
  }
  const [records, plans, meds] = await Promise.all([
    Promise.all(patients.map(p => api(`/health-records?patientId=${p.id}`).catch(()=>[]))),
    Promise.all(patients.map(p => api(`/diet-plan/${p.id}`).catch(()=>({})))),
    Promise.all(patients.map(p => api(`/medicines?patientId=${p.id}`).catch(()=>[]))),
  ]);

  body.innerHTML = patients.map((p, i) => `
    <div class="section">
      <div class="section-head">
        <h2>${p.name} <span class="tag teal">${p.id}</span></h2>
        <span class="tag ${p.status}">${p.status}</span>
      </div>

      <!-- Simulated Realtime ECG -->
      <div class="ecg-container"><div class="ecg-line"></div></div>

      <div style="margin-top:16px;">
        <h3 style="font-size:13px;color:var(--text-muted);text-transform:uppercase;margin-bottom:8px;">Clinical Progress Notes</h3>
        ${(records[i]||[]).map(r => `
          <div class="report-row" style="padding:8px 0;">
            <div style="font-size:11px;color:var(--teal);font-family:var(--font-mono);">${new Date(r.createdAt).toLocaleString()}</div>
            <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;">
              <p style="margin:4px 0;font-size:13px;">${r.note.replace(/</g,'&lt;')}</p>
              <button class="btn xs secondary" onclick="removeHealthRecord('${r.id}')">Remove</button>
            </div>
          </div>
        `).join('') || '<p style="color:var(--text-muted);font-size:12.5px;">No progress notes recorded.</p>'}
        
        <form onsubmit="return addHealthRecord(event,'${p.id}')" style="margin-top:10px;">
          <div class="form-row">
            <input id="hr-${p.id}" placeholder="Add clinical progress observation..." style="flex:1;">
            <button class="btn xs" type="submit">+ Note</button>
          </div>
        </form>
      </div>

      <div style="margin-top:18px;">
        <h3 style="font-size:13px;color:var(--text-muted);text-transform:uppercase;margin-bottom:8px;">Dietary Guidance Plan</h3>
        <textarea class="report-ta" placeholder="Prescribe customized diet requirements..." onblur="saveDietPlan('${p.id}',this.value)">${plans[i] ? (plans[i].text || '') : ''}</textarea>
      </div>

      <div style="margin-top:18px;">
        <h3 style="font-size:13px;color:var(--text-muted);text-transform:uppercase;margin-bottom:8px;">Prescription Medications</h3>
        ${(meds[i]||[]).length ? `
          <div class="table-wrap">
            <table>
              <thead><tr><th>Medicine Name</th><th>Dosage</th><th>Frequency / Instructions</th><th>Action</th></tr></thead>
              <tbody>
                ${meds[i].map(m => `
                  <tr>
                    <td><b>${m.name}</b></td>
                    <td>${m.dosage || '—'}</td>
                    <td>${m.instructions || '—'}</td>
                    <td><button class="btn xs secondary" onclick="removeMedicine('${m.id}')">Remove</button></td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        ` : '<p style="color:var(--text-muted);font-size:12.5px;">No active prescriptions.</p>'}
        
        <form onsubmit="return addMedicine(event,'${p.id}')" style="margin-top:10px;">
          <div class="form-row">
            <input id="med-name-${p.id}" placeholder="Drug name *" required>
            <input id="med-dose-${p.id}" placeholder="Dosage (e.g. 500mg)">
            <input id="med-inst-${p.id}" placeholder="Instructions (e.g. 2x Daily after food)">
            <button class="btn xs" type="submit">+ Prescribe</button>
          </div>
        </form>
      </div>
    </div>
  `).join('');
}

async function renderCarePatient(body) {
  const [records, plan, meds] = await Promise.all([
    api(`/health-records?patientId=${session.user.id}`).catch(()=>[]),
    api(`/diet-plan/${session.user.id}`).catch(()=>({})),
    api(`/medicines?patientId=${session.user.id}`).catch(()=>[])
  ]);

  body.innerHTML = `
    <div class="section">
      <h2>Live Telemetry Monitor</h2>
      <div class="ecg-container"><div class="ecg-line"></div></div>
    </div>

    <div class="section">
      <h2>Clinical Care Notes</h2>
      ${records.length ? records.map(r => `
        <div class="report-row">
          <div style="font-size:11px;color:var(--teal);font-family:var(--font-mono);">${new Date(r.createdAt).toLocaleString()}</div>
          <p style="margin-top:4px;font-size:13.5px;">${r.note.replace(/</g,'&lt;')}</p>
        </div>
      `).join('') : '<p style="color:var(--text-muted)">No notes yet.</p>'}
    </div>

    <div class="section">
      <h2>Prescribed Dietary Plan</h2>
      <div class="report-view">${plan && plan.text ? plan.text.replace(/</g,'&lt;') : 'Standard healthy hospital diet.'}</div>
    </div>

    <div class="section">
      <h2>Active Prescribed Medications</h2>
      ${meds.length ? `
        <div class="table-wrap">
          <table>
            <thead><tr><th>Drug Name</th><th>Dosage</th><th>Instructions</th></tr></thead>
            <tbody>
              ${meds.map(m => `
                <tr><td><b>${m.name}</b></td><td>${m.dosage||'—'}</td><td>${m.instructions||'—'}</td></tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      ` : '<p style="color:var(--text-muted)">No active medication orders.</p>'}
    </div>
  `;
}
async function addHealthRecord(e, patientId) {
  e.preventDefault();
  const el = document.getElementById(`hr-${patientId}`);
  if (!el.value.trim()) return false;
  await api('/health-records', { method: 'POST', body: JSON.stringify({ patientId, note: el.value.trim() }) });
  toast('Clinical note recorded');
  renderView();
  return false;
}
async function removeHealthRecord(id) {
  await api(`/health-records/${id}`, { method: 'DELETE' });
  toast('Note removed');
  renderView();
}
async function saveDietPlan(patientId, text) {
  await api(`/diet-plan/${patientId}`, { method: 'PUT', body: JSON.stringify({ text }) });
  toast('Diet plan updated');
}
async function addMedicine(e, patientId) {
  e.preventDefault();
  const name = document.getElementById(`med-name-${patientId}`).value.trim();
  const dosage = document.getElementById(`med-dose-${patientId}`).value.trim();
  const instructions = document.getElementById(`med-inst-${patientId}`).value.trim();
  if (!name) return false;
  await api('/medicines', { method: 'POST', body: JSON.stringify({ patientId, name, dosage, instructions }) });
  toast('Medicine prescribed');
  renderView();
  return false;
}
async function removeMedicine(id) {
  await api(`/medicines/${id}`, { method: 'DELETE' });
  toast('Prescription removed');
  renderView();
}

/* AMBULANCES */
async function renderAmbulances(body) {
  const rows = await api('/ambulances').catch(()=>[]);
  const canEdit = session.role === 'admin';
  let form = '';

  if (canEdit) {
    form = `
      <div class="section">
        <h2>Register Ambulance Unit</h2>
        <form onsubmit="return addAmbulance(event)">
          <div class="form-row">
            <select id="ambHosp">${hospitals.map(h => `<option value="${h.id}">${h.name}</option>`).join('')}</select>
            <input id="ambVehicle" placeholder="Vehicle Number (e.g. MH-01-AB-1234) *" required>
            <input id="ambDriver" placeholder="Driver Name">
            <input id="ambContact" placeholder="Driver Phone">
            <button class="btn xs" type="submit">+ Add Ambulance</button>
          </div>
        </form>
      </div>
    `;
  }

  body.innerHTML = `
    ${form}
    <div class="section">
      <div class="section-head">
        <h2>Ambulance Fleet Status (${rows.length})</h2>
      </div>
      <div class="ambulance-grid">
        ${rows.map(a => `
          <div class="ambulance-card">
            <div>
              <div class="amb-header">
                <span class="amb-plate">🚑 ${a.vehicleNo}</span>
                <span class="tag ${a.status==='available'?'stable':'moderate'}">${a.status}</span>
              </div>
              <div style="margin-top:10px;font-size:13px;">
                <div><b>Hospital:</b> ${hospName(a.hospitalId)}</div>
                <div><b>Driver:</b> ${a.driverName || '—'}</div>
                <div><b>Contact:</b> ${a.contact ? `<a href="tel:${a.contact}" style="color:var(--teal);text-decoration:none;">📞 ${a.contact}</a>` : '—'}</div>
              </div>
            </div>
            ${canEdit ? `
              <div style="display:flex;gap:6px;margin-top:10px;">
                <select class="mini" style="flex:1;" onchange="editAmbulance('${a.id}','status',this.value)">
                  <option ${a.status==='available'?'selected':''} value="available">🟢 Available</option>
                  <option ${a.status==='on-duty'?'selected':''} value="on-duty">🟡 On Duty</option>
                </select>
                <button class="btn xs secondary" onclick="removeAmbulance('${a.id}')">Remove</button>
              </div>
            ` : ''}
          </div>
        `).join('') || '<div style="color:var(--text-muted)">No ambulances in fleet yet.</div>'}
      </div>
    </div>
  `;
}
async function addAmbulance(e) {
  e.preventDefault();
  await api('/ambulances', {
    method: 'POST',
    body: JSON.stringify({ hospitalId: ambHosp.value, vehicleNo: ambVehicle.value, driverName: ambDriver.value, contact: ambContact.value })
  });
  toast('Ambulance added to fleet');
  renderView();
  return false;
}
async function editAmbulance(id, field, value) {
  await api(`/ambulances/${id}`, { method: 'PUT', body: JSON.stringify({ [field]: value }) });
  toast('Ambulance status updated');
}
async function removeAmbulance(id) {
  if (!confirm('Remove ambulance vehicle from fleet?')) return;
  await api(`/ambulances/${id}`, { method: 'DELETE' });
  toast('Ambulance removed');
  renderView();
}

/* DISEASES */
async function renderDiseases(body) {
  const rows = await api('/diseases').catch(()=>[]);
  const canEdit = session.role === 'admin';
  let form = '';

  if (canEdit) {
    form = `
      <div class="section">
        <h2>Track Epidemic / Disease Outbreak</h2>
        <form onsubmit="return addDisease(event)">
          <div class="form-row">
            <select id="disHosp">${hospitals.map(h => `<option value="${h.id}">${h.name}</option>`).join('')}</select>
            <input id="disName" placeholder="Disease or Outbreak Name *" required>
            <input id="disNotes" placeholder="Advisory notes & protocols" style="flex:2;">
            <button class="btn xs" type="submit">+ Track Condition</button>
          </div>
        </form>
      </div>
    `;
  }

  body.innerHTML = `
    ${form}
    <div class="section">
      <div class="section-head">
        <h2>Regional Disease &amp; Infection Tracking (${rows.length})</h2>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Condition Name</th><th>Hospital Facility</th><th>Protocol Notes</th>${canEdit?'<th>Action</th>':''}</tr></thead>
          <tbody>
            ${rows.map(d => `
              <tr>
                <td><b>${d.name}</b></td>
                <td>${hospName(d.hospitalId)}</td>
                <td>${d.notes || '—'}</td>
                ${canEdit ? `<td><button class="btn xs secondary" onclick="removeDisease('${d.id}')">Remove</button></td>` : ''}
              </tr>
            `).join('') || `<tr><td colspan="4" style="color:var(--text-muted)">No active outbreak tracking records.</td></tr>`}
          </tbody>
        </table>
      </div>
    </div>
  `;
}
async function addDisease(e) {
  e.preventDefault();
  await api('/diseases', { method: 'POST', body: JSON.stringify({ hospitalId: disHosp.value, name: disName.value, notes: disNotes.value }) });
  toast('Disease tracked');
  renderView();
  return false;
}
async function removeDisease(id) {
  await api(`/diseases/${id}`, { method: 'DELETE' });
  toast('Record removed');
  renderView();
}

/* ================= BLOOD DONATION (patient screening form) ================= */
function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}
async function renderDonateBlood(body) {
  const mine = await api('/blood-donations').catch(()=>[]);
  const me = (session.user) || {};
  body.innerHTML = `
    <div class="section">
      <h2>Blood Donor Screening &amp; Appointment</h2>
      <p class="section-desc">Fill this in to schedule a donation. A nurse will review your vitals before the appointment.</p>
      <form onsubmit="return submitDonation(event)">
        <div class="field"><label>Full Name &amp; ID *</label><input id="bdName" value="${me.name||''}" required></div>
        <div class="form-row">
          <div class="field" style="flex:1;"><label>Age (18–65) *</label><input id="bdAge" type="number" min="18" max="65" value="${me.age||''}" required></div>
          <div class="field" style="flex:1;"><label>Body Weight (kg)</label><input id="bdWeight" type="number" step="0.1"></div>
          <div class="field" style="flex:1;"><label>Blood Group *</label>
            <select id="bdBloodGroup" required>
              <option value="">Select</option>
              ${['A+','A-','B+','B-','AB+','AB-','O+','O-'].map(g => `<option ${me.bloodGroup===g?'selected':''}>${g}</option>`).join('')}
            </select>
          </div>
        </div>
        <div class="form-row">
          <div class="field" style="flex:1;"><label>Haemoglobin (Hb)</label><input id="bdHb" placeholder="e.g. 13.5 g/dL"></div>
          <div class="field" style="flex:1;"><label>Blood Pressure</label><input id="bdBp" placeholder="e.g. 120/80"></div>
          <div class="field" style="flex:1;"><label>Pulse Rate</label><input id="bdPulse" placeholder="e.g. 72 bpm"></div>
        </div>
        <div class="field"><label>Past Medical Report (image, if any)</label><input id="bdReport" type="file" accept="image/*"></div>
        <div class="form-row">
          <div class="field" style="flex:1;"><label>Appointment Date *</label><input id="bdDate" type="date" required></div>
          <div class="field" style="flex:1;"><label>Appointment Time *</label><input id="bdTime" type="time" required></div>
        </div>
        <button class="btn xs" type="submit">Submit Donation Request</button>
      </form>
    </div>

    <div class="section">
      <div class="section-head"><h2>My Donation History (${mine.length})</h2></div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Blood Group</th><th>Appointment</th><th>Status</th></tr></thead>
          <tbody>
            ${mine.map(d => `
              <tr>
                <td><span class="tag critical">${d.bloodGroup}</span></td>
                <td>${d.appointmentDate} at ${d.appointmentTime}</td>
                <td><span class="tag ${d.status==='completed'?'stable':(d.status==='rejected'?'critical':'moderate')}">${d.status}</span></td>
              </tr>
            `).join('') || `<tr><td colspan="3" style="color:var(--text-muted)">No donation requests yet.</td></tr>`}
          </tbody>
        </table>
      </div>
    </div>
  `;
}
async function submitDonation(e) {
  e.preventDefault();
  const fileInput = document.getElementById('bdReport');
  let reportImage = null;
  if (fileInput.files[0]) reportImage = await readFileAsDataUrl(fileInput.files[0]);
  await api('/blood-donations', {
    method: 'POST',
    body: JSON.stringify({
      fullName: bdName.value, age: +bdAge.value, weight: bdWeight.value ? +bdWeight.value : null,
      hemoglobin: bdHb.value, bloodPressure: bdBp.value, pulseRate: bdPulse.value, bloodGroup: bdBloodGroup.value,
      reportImage, appointmentDate: bdDate.value, appointmentTime: bdTime.value
    })
  });
  toast('Donation appointment requested');
  renderView();
  return false;
}

/* Nurse/Admin: review donation requests, mark completed */
async function renderBloodDonations(body) {
  const rows = await api('/blood-donations').catch(()=>[]);
  const canManage = session.role === 'admin' || session.role === 'nurse';
  body.innerHTML = `
    <div class="section">
      <div class="section-head"><h2>Blood Donation Appointments (${rows.length})</h2></div>
      <p class="section-desc">Review donor vitals, then mark a donation "Completed" once the unit is collected — this updates the blood bank stock and shows the donor on the admin dashboard.</p>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Donor</th><th>Vitals</th><th>Blood Group</th><th>Appointment</th><th>Report</th><th>Status</th>${canManage?'<th>Actions</th>':''}</tr></thead>
          <tbody>
            ${rows.map(d => `
              <tr>
                <td><b>${d.fullName}</b><br><span class="tag teal" style="margin-top:4px;">${d.patientId}</span></td>
                <td style="font-size:11.5px;">Age ${d.age} · ${d.weight||'—'}kg<br>Hb ${d.hemoglobin||'—'} · BP ${d.bloodPressure||'—'}<br>Pulse ${d.pulseRate||'—'}</td>
                <td><span class="tag critical">${d.bloodGroup}</span></td>
                <td>${d.appointmentDate}<br>${d.appointmentTime}</td>
                <td>${d.reportImageUrl ? `<a href="${d.reportImageUrl}" target="_blank" style="color:var(--cyan)">View</a>` : '—'}</td>
                <td><span class="tag ${d.status==='completed'?'stable':(d.status==='rejected'?'critical':'moderate')}">${d.status}</span></td>
                ${canManage ? `
                  <td>
                    <div class="table-actions">
                      ${d.status==='pending' ? `<button class="btn xs secondary" onclick="setDonationStatus('${d.id}','approved')">Approve</button>` : ''}
                      ${d.status!=='completed' ? `<button class="btn xs" onclick="setDonationStatus('${d.id}','completed')">Mark Completed</button>` : ''}
                      ${d.status!=='rejected' && d.status!=='completed' ? `<button class="btn xs secondary" onclick="setDonationStatus('${d.id}','rejected')">Reject</button>` : ''}
                    </div>
                  </td>
                ` : ''}
              </tr>
            `).join('') || `<tr><td colspan="7" style="color:var(--text-muted)">No blood donation appointments yet.</td></tr>`}
          </tbody>
        </table>
      </div>
    </div>
  `;
}
async function setDonationStatus(id, status) {
  await api(`/blood-donations/${id}`, { method: 'PUT', body: JSON.stringify({ status }) });
  toast(status === 'completed' ? 'Donation marked completed — stock updated' : `Donation ${status}`);
  renderView();
}

/* ================= MEDICINE ALARMS ================= */
async function renderMedicineAlarms(body) {
  if (session.role === 'nurse') return renderMedicineAlarmsNurse(body);
  const rows = await api('/medicine-alarms').catch(()=>[]);
  startAlarmWatcher(rows);
  body.innerHTML = `
    <div class="section">
      <h2>Medicine Reminders</h2>
      <p class="section-desc">Set by your nurse. This screen will chime and toast when it's time for a dose while it's open.</p>
      ${rows.length ? rows.map(a => `
        <div class="report-row">
          <div style="display:flex;justify-content:space-between;align-items:center;">
            <div>
              <b>${a.medicineName}</b>
              <div style="font-size:11.5px;color:var(--text-muted);margin-top:2px;">${a.notes||''}</div>
            </div>
            <div>${a.times.map(t => `<span class="tag teal" style="margin-left:6px;">${t}</span>`).join('')}</div>
          </div>
        </div>
      `).join('') : '<p style="color:var(--text-muted);padding:14px 0;">No reminders set yet.</p>'}
    </div>
  `;
}
async function renderMedicineAlarmsNurse(body) {
  const [patients, rows] = await Promise.all([api('/patients').catch(()=>[]), api('/medicine-alarms').catch(()=>[])]);
  body.innerHTML = `
    <div class="section">
      <h2>Set Post-Op Medicine Reminder</h2>
      <form onsubmit="return addAlarm(event)">
        <div class="form-row">
          <select id="almPatient" required>${patients.map(p => `<option value="${p.id}">${p.name} (${p.id})</option>`).join('')}</select>
          <input id="almMed" placeholder="Medicine name *" required>
          <input id="almTimes" placeholder="Times, comma separated e.g. 08:00, 14:00, 20:00" style="flex:2;" required>
          <button class="btn xs" type="submit">+ Set Alarm</button>
        </div>
        <div class="field" style="margin-top:8px;"><input id="almNotes" placeholder="Notes (optional)"></div>
      </form>
    </div>
    <div class="section">
      <div class="section-head"><h2>Active Reminders (${rows.length})</h2></div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Patient</th><th>Medicine</th><th>Times</th><th>Notes</th><th>Action</th></tr></thead>
          <tbody>
            ${rows.map(a => `
              <tr>
                <td><b>${a.patientId}</b></td>
                <td>${a.medicineName}</td>
                <td>${a.times.join(', ')}</td>
                <td>${a.notes||'—'}</td>
                <td><button class="btn xs secondary" onclick="removeAlarm('${a.id}')">Remove</button></td>
              </tr>
            `).join('') || `<tr><td colspan="5" style="color:var(--text-muted)">No reminders set.</td></tr>`}
          </tbody>
        </table>
      </div>
    </div>
  `;
}
async function addAlarm(e) {
  e.preventDefault();
  const times = almTimes.value.split(',').map(t => t.trim()).filter(Boolean);
  await api('/medicine-alarms', { method: 'POST', body: JSON.stringify({ patientId: almPatient.value, medicineName: almMed.value, times, notes: almNotes.value }) });
  toast('Medicine alarm set for patient');
  renderView();
  return false;
}
async function removeAlarm(id) {
  await api(`/medicine-alarms/${id}`, { method: 'DELETE' });
  toast('Reminder removed');
  renderView();
}
// Lightweight client-side alarm: checks once a minute while a patient has the
// Reminders screen open, and toasts + browser-notifies on an exact HH:MM match.
let _alarmInterval = null, _alarmFiredThisMinute = {};
function startAlarmWatcher(rows) {
  if (_alarmInterval) clearInterval(_alarmInterval);
  if (!rows || !rows.length) return;
  if (window.Notification && Notification.permission === 'default') Notification.requestPermission().catch(()=>{});
  const check = () => {
    const now = new Date();
    const hhmm = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;
    rows.forEach(a => {
      if (a.times.includes(hhmm)) {
        const key = a.id + hhmm;
        if (_alarmFiredThisMinute[key]) return;
        _alarmFiredThisMinute[key] = true;
        toast(`⏰ Time to take ${a.medicineName}`);
        if (window.Notification && Notification.permission === 'granted') new Notification('Medicine Reminder', { body: `Time to take ${a.medicineName}` });
      }
    });
  };
  check();
  _alarmInterval = setInterval(check, 30000);
}

/* ================= PRESCRIPTIONS ================= */
async function renderPrescriptions(body) {
  if (session.role === 'doctor') return renderPrescriptionsDoctor(body);
  const rows = await api(`/prescriptions?patientId=${session.user.id}`).catch(()=>[]);
  body.innerHTML = `
    <div class="section"><h2>My Prescriptions</h2></div>
    ${rows.map(r => `
      <div class="section">
        <div class="section-head"><h2 style="font-size:15px;">${new Date(r.createdAt).toLocaleString()}</h2></div>
        ${r.text ? `<div class="report-view">${r.text.replace(/</g,'&lt;')}</div>` : ''}
        ${r.extractedText ? `
          <h3 style="font-size:13px;color:var(--text-muted);text-transform:uppercase;margin:12px 0 6px;">Clean, Readable Medicine List</h3>
          <div class="report-view" style="white-space:pre-wrap;">${r.extractedText.replace(/</g,'&lt;')}</div>
        ` : ''}
        ${r.photos && r.photos.length ? `
          <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px;">
            ${r.photos.map(p => `<a href="${p}" target="_blank"><img src="${p}" style="width:90px;height:90px;object-fit:cover;border-radius:8px;border:1px solid var(--border);"></a>`).join('')}
          </div>
        ` : ''}
      </div>
    `).join('') || '<div class="section"><p style="color:var(--text-muted)">No prescriptions yet.</p></div>'}
  `;
}
let _rxPhotos = [];
async function renderPrescriptionsDoctor(body) {
  const patients = await api('/patients').catch(()=>[]);
  _rxPhotos = [];
  body.innerHTML = `
    <div class="section">
      <h2>Write a Prescription</h2>
      <p class="section-desc">Type the prescription, or attach photos of a handwritten/printed one — Claude will read the photos and produce a clean, patient-readable medicine list automatically.</p>
      <form onsubmit="return submitPrescription(event)">
        <div class="field"><label>Patient *</label><select id="rxPatient" required>${patients.map(p => `<option value="${p.id}">${p.name} (${p.id})</option>`).join('')}</select></div>
        <div class="field"><label>Prescription Text</label><textarea id="rxText" class="report-ta" placeholder="e.g. Amoxicillin 500mg — 1 tablet 3x daily after food for 5 days"></textarea></div>
        <div class="field">
          <label>Attach Photo(s)</label>
          <input id="rxPhotoFile" type="file" accept="image/*" multiple onchange="stagePrescriptionPhotos(event)">
          <div id="rxPhotoPreview" style="display:flex;gap:8px;margin-top:8px;flex-wrap:wrap;"></div>
        </div>
        <button class="btn xs" type="submit">Send Prescription to Patient</button>
      </form>
    </div>
  `;
}
async function stagePrescriptionPhotos(e) {
  const files = Array.from(e.target.files || []);
  for (const f of files) _rxPhotos.push(await readFileAsDataUrl(f));
  document.getElementById('rxPhotoPreview').innerHTML = _rxPhotos.map(p => `<img src="${p}" style="width:70px;height:70px;object-fit:cover;border-radius:8px;border:1px solid var(--border);">`).join('');
}
async function submitPrescription(e) {
  e.preventDefault();
  if (!rxText.value.trim() && !_rxPhotos.length) { toast('Add prescription text or a photo'); return false; }
  toast(_rxPhotos.length ? 'Sending — reading photo(s)…' : 'Sending prescription…');
  const res = await api('/prescriptions', { method: 'POST', body: JSON.stringify({ patientId: rxPatient.value, text: rxText.value.trim(), photos: _rxPhotos }) });
  toast(res.extractedText ? 'Prescription sent — clean medicine list generated' : 'Prescription sent to patient');
  renderView();
  return false;
}

/* ================= QUICK SOS (patient) ================= */
async function renderQuickSos(body) {
  const me = session.user || {};
  body.innerHTML = `
    <div class="section" style="text-align:center;border-color:var(--alert);">
      <h2 style="color:var(--alert);">Quick SOS</h2>
      <p class="section-desc">One tap sends your live location to the nearest hospital and dispatches your saved ambulance contact.</p>
      <button class="btn danger" style="width:220px;height:220px;border-radius:50%;font-size:20px;font-weight:800;margin:20px auto;" onclick="fireQuickSos()">🚨 QUICK SOS</button>
      <div id="quickSosResult"></div>
    </div>
    <div class="section">
      <h2>Your Saved Ambulance Contact</h2>
      <p class="section-desc">Quick SOS calls this ambulance directly, alongside the nearest hospital.</p>
      <form onsubmit="return saveAmbulancePref(event)">
        <div class="form-row">
          <input id="ambName" placeholder="Ambulance / service name" value="${me.preferredAmbulanceName||''}">
          <input id="ambContact" placeholder="Contact number *" value="${me.preferredAmbulanceContact||''}" required>
          <button class="btn xs" type="submit">Save</button>
        </div>
      </form>
    </div>
  `;
}
async function saveAmbulancePref(e) {
  e.preventDefault();
  await api(`/patients/${session.user.id}/ambulance-preference`, { method: 'PUT', body: JSON.stringify({ name: ambName.value, contact: ambContact.value }) });
  session.user.preferredAmbulanceName = ambName.value;
  session.user.preferredAmbulanceContact = ambContact.value;
  toast('Ambulance contact saved');
  return false;
}
function fireQuickSos() {
  const resultBox = document.getElementById('quickSosResult');
  resultBox.innerHTML = '<p style="color:var(--text-muted);margin-top:14px;">Getting your location…</p>';
  const send = async (lat, lng) => {
    try {
      const res = await api('/sos', { method: 'POST', body: JSON.stringify({ reason: 'Quick SOS', latitude: lat, longitude: lng }) });
      resultBox.innerHTML = `
        <div class="report-row" style="margin-top:16px;text-align:left;">
          <p><b>🏥 Nearest Hospital:</b> ${res.hospital ? `${res.hospital.name} (${res.hospital.distanceKm} km away)` : 'Not determined — check SOS Alerts for follow-up'}</p>
          ${res.hospital && res.hospital.address ? `<p style="color:var(--text-muted);font-size:12.5px;">${res.hospital.address}</p>` : ''}
          <p><b>🚑 Ambulance:</b> ${res.ambulanceName || 'Dispatch team notified'} ${res.ambulanceContact ? `— <a href="tel:${res.ambulanceContact}" style="color:var(--teal);">${res.ambulanceContact}</a>` : ''}</p>
          ${res.mapUrl ? `<p><a href="${res.mapUrl}" target="_blank" style="color:var(--cyan);">📍 View my location on Google Maps</a></p>` : ''}
        </div>
      `;
      toast('🚨 SOS sent — hospital and ambulance notified');
    } catch (err) {
      resultBox.innerHTML = `<p style="color:var(--alert);margin-top:14px;">${err.message}</p>`;
    }
  };
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      (pos) => send(pos.coords.latitude, pos.coords.longitude),
      () => send(null, null),
      { enableHighAccuracy: true, timeout: 8000 }
    );
  } else {
    send(null, null);
  }
}

/* ACCOUNT SETTINGS */
async function renderAccount(body) {
  const me = (session && session.user) ? session.user : {};
  body.innerHTML = `
    <div class="section">
      <h2>Account &amp; Security Settings</h2>
      <p class="section-desc">Manage profile avatar, physical address, and access credentials.</p>
      
      <div style="display:flex;align-items:center;gap:18px;margin:20px 0;">
        ${me.photo ? `<img id="acctPhotoPreview" src="${me.photo}" style="width:70px;height:70px;border-radius:50%;object-fit:cover;border:2px solid var(--teal);">` : `<div id="acctPhotoPreview" style="width:70px;height:70px;border-radius:50%;background:var(--card-alt);border:2px solid var(--teal);display:flex;align-items:center;justify-content:center;font-size:24px;color:var(--teal);">${(me.name||'?')[0]}</div>`}
        <div>
          <label class="btn xs secondary" style="cursor:pointer;">
            Change Photo
            <input type="file" id="acctPhotoFile" accept="image/*" onchange="previewAccountPhoto(event)" style="display:none;">
          </label>
          <div style="font-size:11px;color:var(--text-muted);margin-top:6px;">JPG, PNG up to 2MB</div>
        </div>
      </div>

      <form onsubmit="return saveAccount(event)">
        <div class="field"><label>Registered Address</label><input id="acctAddress" value="${me.address||''}" placeholder="Your full residential or facility address"></div>
        <div class="field"><label>New Password (Leave blank to keep existing)</label><input id="acctPassword" type="password" placeholder="••••••••"></div>
        <button class="btn xs" type="submit" style="margin-top:10px;">Save Profile Changes</button>
      </form>
    </div>
  `;
}

let _acctPhotoData = null;
function previewAccountPhoto(e) {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    _acctPhotoData = reader.result;
    const preview = document.getElementById('acctPhotoPreview');
    preview.outerHTML = `<img id="acctPhotoPreview" src="${reader.result}" style="width:70px;height:70px;border-radius:50%;object-fit:cover;border:2px solid var(--teal);">`;
  };
  reader.readAsDataURL(file);
}

async function saveAccount(e) {
  e.preventDefault();
  const body = { address: document.getElementById('acctAddress').value };
  const pw = document.getElementById('acctPassword').value;
  if (pw) body.password = pw;
  if (_acctPhotoData) body.photo = _acctPhotoData;
  const data = await api('/me', { method: 'PUT', body: JSON.stringify(body) });
  session.user = data.user;
  toast('Account profile updated successfully');
  renderView();
  return false;
}



async function bootRolePage() {
  const raw = localStorage.getItem('mediPlusSession');
  if (!raw) { window.location.href = 'index.html'; return; }
  try { session = JSON.parse(raw); } catch (e) { localStorage.removeItem('mediPlusSession'); window.location.href='index.html'; return; }
  if (!session || !session.token || !session.role) { localStorage.removeItem('mediPlusSession'); window.location.href='index.html'; return; }
  if (PAGE_ROLE && session.role !== PAGE_ROLE) { window.location.href = `${session.role}.html`; return; }
  try { await startApp(); } catch (e) {
    console.error(e);
    localStorage.removeItem('mediPlusSession');
    window.location.href = 'index.html';
  }
}
window.addEventListener('load', bootRolePage);
