// ================================================================
// Medi+ Command — Android app backend address
// ================================================================
// A phone app can NOT reach "localhost:4000" — that means "this phone
// itself", not your computer. You must put your computer's LAN IP address
// here instead, so the phone can find the backend over WiFi.
//
// HOW TO FIND YOUR COMPUTER'S LAN IP:
//   Windows:  open Command Prompt, run "ipconfig", look for "IPv4 Address"
//             under your active WiFi adapter (looks like 192.168.x.x)
//   Mac:      System Settings > Wi-Fi > Details > IP Address
//             (or run "ipconfig getifaddr en0" in Terminal)
//   Linux:    run "hostname -I" or "ip addr" in a terminal
//
// Your phone and computer MUST be connected to the same WiFi network.
// The backend must be running (npm start in the backend folder) whenever
// you use the app.
// ================================================================
window.MEDIPLUS_API_HOST = 'http://192.168.1.100:4000'; // <-- CHANGE THIS to your computer's LAN IP
