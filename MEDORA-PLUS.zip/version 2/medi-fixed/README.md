# Medi+ Command — Split Role Frontends

The single frontend has been split into separate HTML entry points while keeping the same backend, SQLite data, REST API, Socket.IO real-time synchronization, permissions, and UI behavior.

## Frontend files
- `index.html` — login / patient self-registration / SOS
- `admin.html` — Hospital Admin portal
- `doctor.html` — Doctor portal
- `nurse.html` — Nurse portal
- `patient.html` — Patient portal
- `common.css` — shared visual design
- `login.js` — login and SOS controller
- `app.js` — shared role portal controller and all view renderers

## Run
```
cd backend
npm install
npm start
```
Open `http://localhost:4000/`. The server serves `frontend/index.html` at `/` and role pages at `/admin.html`, `/doctor.html`, `/nurse.html`, and `/patient.html`.

Login creates a backend session and stores only the session token/user payload in `localStorage` so the selected role page can load. All cross-role communication still happens through the same REST API and Socket.IO server.

Demo accounts:
- Admin: `ADM-1001` / `admin123`
- Doctor: `DR-1001` / `doc123`
- Nurse: `NR-1001` / `nurse123`
- Patient: `PT-001` / `pat123`

## Security fixes in this version
- **Passwords are hashed with bcrypt** (`bcryptjs`), both in seed data and on every create/update. Any existing `medi-plus.db` with old plaintext passwords is auto-migrated to hashed passwords the next time the server starts.
- **Nurses can no longer read another hospital's health records, medicines, or diet plans** — `canTouchPatientRecord()` now enforces the same hospital scoping nurses already had everywhere else.
- **`PUT /api/staff/:role/:id` no longer accepts arbitrary body keys as SQL column names** (was a SQL-injection / mass-assignment hole) — it now uses the same explicit field whitelist as every other update route.
- **IDs (hospitals, doctors, nurses, patients) are generated from the current max numeric suffix**, not `COUNT(*)+1`, so they no longer collide after a deletion or under concurrent creates.
- **Login and the public SOS endpoint are rate-limited** (20 login attempts / 15 min per IP, 10 SOS submissions / 10 min per IP) via `express-rate-limit`.
- **Sessions now expire** after 12 hours of inactivity (sliding) instead of living forever until server restart, and are swept periodically.
- **Request body size is capped at 1MB** and CORS can be locked to specific origins via an `ALLOWED_ORIGINS` env var (comma-separated) — left open by default for local dev.

None of this changes any request/response shapes, so the existing frontend works unmodified.

## Installable app (PWA) — no Android Studio needed

The frontend is now a installable Progressive Web App: `manifest.json`, `sw.js` (service worker), app icons under `frontend/icons/`, and `pwa.js` (registers the service worker and shows an "Install App" button when the browser allows it) are wired into every page.

**Important — most browsers require HTTPS to fully install a PWA** (an automatic install prompt, offline caching via the service worker). Plain `http://` only works for this on `localhost` itself. Two ways to use it:

1. **Manual "Add to Home Screen" (works right now, over plain WiFi HTTP):**
   - Start the backend: `cd backend && npm start`.
   - Find your computer's LAN IP (`ipconfig` / `ipconfig getifaddr en0` / `hostname -I`) and open `http://<your-ip>:4000` in your phone's browser (same WiFi network).
   - Chrome (Android): menu (⋮) → "Add to Home screen". Safari (iOS): Share button → "Add to Home Screen".
   - This adds a real icon that opens the app in its own window — no browser bars. The automatic "Install App" button on the login screen and offline caching won't appear/won't work over plain HTTP on a non-localhost address (browser security restriction), but the manual add-to-home-screen path always works.

2. **Full install prompt + offline caching (needs HTTPS):** either deploy the backend to a host that gives you free HTTPS (Render, Railway, Fly.io, etc.) and use that public URL, or tunnel your local server with something like `ngrok http 4000` and use the `https://...ngrok...` URL it gives you. Once loaded over HTTPS, the "📲 Install App on This Device" button on the login screen will light up automatically and the service worker will cache the app shell for offline use.

## Android app (real .apk)

A ready-to-build Capacitor Android project also lives in `mobile/` — see `mobile/README.md`. It needs Android Studio (or the Android SDK + Gradle) on your machine to compile the actual `.apk`; the whole project is pre-configured so it's just a few commands away.

## New: Google Sign-In, Phone OTP, and Forgot Password

**Google Sign-In**
1. Create an OAuth 2.0 "Web application" Client ID at https://console.cloud.google.com/apis/credentials and add your app's URL under "Authorized JavaScript origins".
2. Paste the Client ID into `GOOGLE_CLIENT_ID` near the top of `frontend/login.js`.
3. Also set it as an env var on the backend, `GOOGLE_CLIENT_ID=...`, so the server can confirm the token was issued for your app (recommended but not required to make the flow work).
4. Clicking "Sign in with Google" now sends the ID token to `POST /api/auth/google`, which verifies it directly with Google, then finds-or-creates a **patient** account linked by Google account ID / email and logs them straight in — no phone number needed.

**Phone OTP** (patient login/self-registration)
- `POST /api/auth/otp/request { phone }` — generates and "sends" a 6-digit code.
- `POST /api/auth/otp/verify { phone, otp, name? }` — verifies the code, then logs in the existing patient with that phone, or creates a new one if none exists.
- Reachable from the login screen via "Sign in with phone OTP instead" under the Patient tab.

**Forgot password** (all roles)
- `POST /api/auth/password/forgot/request { role, id }` — sends a reset code to the account's phone (patients) or email (staff).
- `POST /api/auth/password/forgot/verify { role, id, otp, newPassword }` — verifies the code and sets the new password.
- Reachable from the login screen's "Forgot password?" link.
- **Staff accounts (admin/doctor/nurse) need an `email` on file** to use this — there's no UI to set one yet, so seed/set it directly, e.g.:
  ```sql
  UPDATE doctors SET email='doc@example.com' WHERE id='DR-1001';
  ```

**No SMS/email provider is wired up.** Every code is logged to the server console (`[OTP] ... code for <target>: <code>`), and — only when `NODE_ENV` is not `production` — echoed back in the API response as `devOtp` so you can test the whole flow without a real gateway. To go live, plug a provider (Twilio, MSG91, AWS SES, etc.) into `sendOtp()` in `backend/server.js`, and make sure `NODE_ENV=production` is set so codes stop being echoed to API responses.

## New: Blood donation intake, medicine alarms, doctor reschedule/prescriptions, Quick SOS

**Blood donation screening & appointment** (Patient → "Donate Blood")
- Patient fills full name/ID, age (18–65, validated server-side), weight, haemoglobin, blood pressure, pulse rate, blood group (required), an optional past-report image, and an appointment date/time.
- `POST /api/blood-donations` creates it as `pending`. A nurse/admin reviews it under "Blood Donations" (`GET/PUT /api/blood-donations`) and can `approve`, `reject`, or mark `completed`.
- Marking `completed` automatically adds one unit to that hospital's blood bank stock for the donor's group, and notifies the admin — the donor's name then shows in the "Recent Successful Blood Donations" panel on the Admin overview dashboard, exactly as specified.

**Medicine alarms** (Nurse → "Medicine Alarms", Patient → "Medicine Reminders")
- A nurse sets one or more reminder times (`HH:MM`) per medicine for a patient who's returned after an operation (`POST/PUT/DELETE /api/medicine-alarms`).
- The patient's "Medicine Reminders" screen polls the current time every 30s while open and toasts + fires a browser `Notification` at each scheduled time.

**Doctor: propose a new slot when busy** (Doctor → "Appointments")
- `PUT /api/appointments/:id` now also accepts `{ date }`. Clicking "I'm busy — propose new slot" sets the appointment to `rescheduled` with the new date and notifies the patient.

**Doctor: prescriptions, including photo read-back** (Doctor → "Prescriptions", Patient → "My Prescriptions")
- A doctor can type a prescription and/or attach photos of a handwritten/printed one (`POST /api/prescriptions`).
- If a photo is attached **and `ANTHROPIC_API_KEY` is set** on the backend, the photo(s) are sent to Claude's vision API (`claude-sonnet-4-6`) to transcribe and reformat the contents into a clean, plain-language medicine list, stored as `extractedText` and shown to the patient alongside the original photo. Without a key, the photo is still saved and shown — just without the automatic read-out. Set the key as an env var before starting the server: `ANTHROPIC_API_KEY=sk-ant-... npm start`.

**Quick SOS** (Patient → "Quick SOS")
- A patient can save a trusted ambulance contact (name + number) under "Quick SOS" — this is *their own* ambulance, not the hospital fleet.
- The big "🚨 QUICK SOS" button grabs the browser's GPS location and calls `POST /api/sos`, which: finds the nearest hospital by straight-line distance, dispatches the patient's saved ambulance (falling back to an available hospital-fleet ambulance if none is saved), and returns a `https://www.google.com/maps?q=lat,lng` link — all shown immediately on screen, plus notifications pushed to the admin and that hospital.
- The original public "Emergency SOS" button on the login page (for people who aren't logged in) still works unchanged; Quick SOS is the enhanced, logged-in-patient version with a saved ambulance and auto-routing.

**Storage note ("separate folder... save the data of all users")**
- Donor report images and prescription photos are no longer kept only as giant base64 blobs in the database — they're written to disk under `backend/uploads/<role>/<userId>/...`, one folder per user, and the database just stores the relative path. This folder is created automatically the first time a user uploads something.

**Encryption note ("end-to-end encryption for all users")**
- Sensitive fields in the new tables (donor vitals, prescription text) are encrypted at rest with AES-256-GCM before being written to SQLite (`backend/db.js` → `encryptField`/`decryptField`). Set `ENCRYPTION_KEY` (a 32-byte hex string) as an env var in production, or a random key is generated per boot (fine for local testing, but means old encrypted rows become unreadable after a restart without a fixed key).
- To be transparent: this is **encryption at rest**, protecting the database file/backups from someone who gets raw file access. It is not full end-to-end encryption where only the patient's device holds the key — that would require the browser itself to manage keys and would break server-side features like the admin/nurse dashboards reading that data at all. If true end-to-end (client-held-key) encryption is what you need for a specific field, let me know and we can scope that separately.
