const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const rateLimit = require('express-rate-limit');
const db = require('./db');

const app = express();

// Lock CORS to known origins in production; wide open in dev so the split
// frontend works from any local port. Set ALLOWED_ORIGINS as a comma-separated
// list (e.g. "https://mediplus.example.com") to restrict this for real deployments.
const allowedOrigins = (process.env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
app.use(cors(allowedOrigins.length ? { origin: allowedOrigins } : {}));
app.use(express.json({ limit: '1mb' }));

// Basic brute-force protection. Login and the public SOS endpoint are the two
// unauthenticated write paths worth throttling by IP.
const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 20, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many attempts, please try again later.' } });
const sosLimiter = rateLimit({ windowMs: 10 * 60 * 1000, max: 10, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many requests, please slow down.' } });
// OTP requests are the one flow that can "spam" a real phone/email, so it's
// throttled tighter than login (which only burns a guess, not an SMS credit).
const otpLimiter = rateLimit({ windowMs: 10 * 60 * 1000, max: 5, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many OTP requests, please try again later.' } });

// Serve the split role-based frontend from the backend server.
const FRONTEND_DIR = path.join(__dirname, '..', 'frontend');
app.use(express.static(FRONTEND_DIR));
app.get('/', (req, res) => res.sendFile(path.join(FRONTEND_DIR, 'index.html')));

/* ---------------- per-user file storage ----------------
 * Every uploaded file (donation screening reports, prescription photos, etc.)
 * is written to its own folder per role+id under backend/uploads, instead of
 * living only as a giant base64 blob inside the database. The DB stores just
 * the relative path, which is what's returned to clients and served below.
 */
const UPLOADS_DIR = path.join(__dirname, 'uploads');
app.use('/uploads', express.static(UPLOADS_DIR));
function saveUserFile(role, id, label, dataUrl) {
  if (!dataUrl || typeof dataUrl !== 'string' || !dataUrl.startsWith('data:')) return dataUrl || null;
  const match = dataUrl.match(/^data:([^;]+);base64,(.+)$/);
  if (!match) return dataUrl;
  const mime = match[1];
  const ext = (mime.split('/')[1] || 'bin').split('+')[0].replace(/[^a-z0-9]/gi, '') || 'bin';
  const dir = path.join(UPLOADS_DIR, role, String(id).replace(/[^a-zA-Z0-9_-]/g, '_'));
  fs.mkdirSync(dir, { recursive: true });
  const filename = `${label}-${Date.now()}-${crypto.randomBytes(4).toString('hex')}.${ext}`;
  fs.writeFileSync(path.join(dir, filename), Buffer.from(match[2], 'base64'));
  return `/uploads/${role}/${path.basename(dir)}/${filename}`;
}
function saveUserFiles(role, id, label, dataUrls) {
  if (!Array.isArray(dataUrls)) return [];
  return dataUrls.slice(0, 6).map((d, i) => saveUserFile(role, id, `${label}${i + 1}`, d)).filter(Boolean);
}

/* ---------------- distance helper (for "nearest hospital") ---------------- */
function haversineKm(lat1, lon1, lat2, lon2) {
  const R = 6371, toRad = (d) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1), dLon = toRad(lon2 - lon1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
function nearestHospital(lat, lng) {
  if (lat == null || lng == null) return null;
  const all = db.prepare('SELECT * FROM hospitals WHERE latitude IS NOT NULL AND longitude IS NOT NULL').all();
  if (!all.length) return null;
  let best = null, bestDist = Infinity;
  for (const h of all) {
    const d = haversineKm(lat, lng, h.latitude, h.longitude);
    if (d < bestDist) { bestDist = d; best = h; }
  }
  return best ? { ...best, distanceKm: Math.round(bestDist * 10) / 10 } : null;
}


const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

/* ---------------- in-memory sessions ---------------- */
const sessions = new Map(); // token -> {role, id, hospitalId, expiresAt}
const SESSION_TTL_MS = 12 * 60 * 60 * 1000; // 12 hours

function newToken() { return crypto.randomBytes(24).toString('hex'); }
function createSession(role, id, hospitalId) {
  const token = newToken();
  sessions.set(token, { role, id, hospitalId, expiresAt: Date.now() + SESSION_TTL_MS });
  return token;
}
// Periodically sweep expired sessions so the map doesn't grow unbounded.
setInterval(() => {
  const now = Date.now();
  for (const [token, sess] of sessions) if (sess.expiresAt <= now) sessions.delete(token);
}, 10 * 60 * 1000).unref();

function auth(req, res, next) {
  const token = (req.headers.authorization || '').replace('Bearer ', '');
  const sess = sessions.get(token);
  if (!sess || sess.expiresAt <= Date.now()) {
    if (sess) sessions.delete(token);
    return res.status(401).json({ error: 'Not authenticated' });
  }
  sess.expiresAt = Date.now() + SESSION_TTL_MS; // sliding expiry on activity
  req.session = sess;
  next();
}
function requireRole(...roles) {
  return (req, res, next) => {
    if (!roles.includes(req.session.role)) return res.status(403).json({ error: 'Forbidden for this role' });
    next();
  };
}
// Like auth(), but doesn't reject when there's no/invalid token — just leaves
// req.session unset. Used by routes (like public SOS) that work either way
// but personalize when the caller happens to be logged in.
function optionalAuth(req, res, next) {
  const token = (req.headers.authorization || '').replace('Bearer ', '');
  const sess = sessions.get(token);
  if (sess && sess.expiresAt > Date.now()) {
    sess.expiresAt = Date.now() + SESSION_TTL_MS;
    req.session = sess;
  }
  next();
}

/* ---------------- OTP (phone/email one-time codes) ---------------- */
// No SMS/email provider is wired up here — sendOtp() is the single place to
// plug one in (Twilio, MSG91, SES, etc.) via env vars. Until then, the code
// is logged server-side and, only outside production, echoed back in the API
// response as `devOtp` so the flow is testable without a real gateway.
const OTP_TTL_MS = 5 * 60 * 1000; // 5 minutes
const OTP_MAX_ATTEMPTS = 5;
function generateOtpCode() { return String(crypto.randomInt(100000, 1000000)); } // 6 digits
function sendOtp(target, code, purpose) {
  // TODO: integrate a real SMS/email provider here.
  console.log(`[OTP] ${purpose} code for ${target}: ${code} (valid ${OTP_TTL_MS / 60000} min)`);
}
function createOtp(target, purpose, role) {
  db.prepare('DELETE FROM otps WHERE target=? AND purpose=?').run(target, purpose); // one live code per target+purpose
  const code = generateOtpCode();
  const id = 'OTP-' + Date.now() + '-' + Math.floor(Math.random() * 999);
  db.prepare('INSERT INTO otps (id,target,purpose,codeHash,role,attempts,expiresAt,createdAt) VALUES (?,?,?,?,?,0,?,?)')
    .run(id, target, purpose, db.hashPassword(code), role || null, new Date(Date.now() + OTP_TTL_MS).toISOString(), new Date().toISOString());
  sendOtp(target, code, purpose);
  return { code };
}
// Verifies and, on success, consumes the code (deletes it so it can't be replayed).
function verifyOtp(target, purpose, code) {
  const row = db.prepare('SELECT * FROM otps WHERE target=? AND purpose=?').get(target, purpose);
  if (!row) return { ok: false, error: 'No OTP was requested for this target' };
  if (new Date(row.expiresAt).getTime() <= Date.now()) {
    db.prepare('DELETE FROM otps WHERE id=?').run(row.id);
    return { ok: false, error: 'OTP has expired, please request a new one' };
  }
  if (row.attempts >= OTP_MAX_ATTEMPTS) {
    db.prepare('DELETE FROM otps WHERE id=?').run(row.id);
    return { ok: false, error: 'Too many incorrect attempts, please request a new OTP' };
  }
  if (!db.verifyPassword(code, row.codeHash)) {
    db.prepare('UPDATE otps SET attempts=attempts+1 WHERE id=?').run(row.id);
    return { ok: false, error: 'Incorrect OTP' };
  }
  db.prepare('DELETE FROM otps WHERE id=?').run(row.id);
  return { ok: true, role: row.role };
}
function maskTarget(target) {
  if (!target) return target;
  if (target.includes('@')) {
    const [user, domain] = target.split('@');
    return (user.length <= 2 ? user[0] || '*' : user.slice(0, 2)) + '***@' + domain;
  }
  return target.length <= 4 ? '***' + target.slice(-2) : '***' + target.slice(-4);
}

/* ---------------- realtime helper ---------------- */
// Broadcasts to everyone; frontend filters by relevance. Simple & reliable for this scale.
function broadcast(event, payload) {
  io.emit(event, payload);
}
function notify(audience, message) {
  const n = { id: 'N-' + Date.now() + '-' + Math.floor(Math.random() * 999), audience, message, createdAt: new Date().toISOString(), read: 0 };
  db.prepare('INSERT INTO notifications (id,audience,message,createdAt,read) VALUES (?,?,?,?,0)')
    .run(n.id, n.audience, n.message, n.createdAt);
  broadcast('notification', n);
}

/* ================= AUTH ================= */
// Accepts either the assigned ID or the account's full name as the identifier,
// per "login using ID or full name" — password (or, for patients, phone) still required.
function findAccount(table, identifier, password, extraPasswordCol) {
  const byId = db.prepare(`SELECT * FROM ${table} WHERE id=?`).get(identifier);
  const row = byId || db.prepare(`SELECT * FROM ${table} WHERE LOWER(name)=LOWER(?)`).get(identifier);
  if (!row) return null;
  // Main password field is bcrypt-hashed; extraPasswordCol (patient phone) is a
  // plain alternate credential, not a hashed secret, so it's compared directly.
  const passOk = db.verifyPassword(password, row.password) || (extraPasswordCol && row[extraPasswordCol] === password);
  return passOk ? row : null;
}
app.post('/api/login', loginLimiter, (req, res) => {
  const { role, id, password } = req.body;
  let row = null;
  if (role === 'admin') row = findAccount('admins', id, password);
  else if (role === 'doctor') row = findAccount('doctors', id, password);
  else if (role === 'nurse') row = findAccount('nurses', id, password);
  else if (role === 'patient') row = findAccount('patients', id, password, 'phone');
  else return res.status(400).json({ error: 'Unknown role' });

  if (!row) return res.status(401).json({ error: 'Invalid ID/name or password' });

  const token = createSession(role, row.id, row.hospitalId || null);
  const { password: _pw, ...safe } = row;
  res.json({ token, role, user: safe });
});

app.post('/api/logout', auth, (req, res) => {
  const token = (req.headers.authorization || '').replace('Bearer ', '');
  sessions.delete(token);
  res.json({ ok: true });
});

/* ---- Phone OTP: login existing patients or self-register new ones ---- */
// Request a code for a phone number. Doesn't reveal whether the number is
// already registered — the same response either way — so it can't be used
// to enumerate patients.
app.post('/api/auth/otp/request', otpLimiter, (req, res) => {
  const phone = (req.body.phone || '').trim();
  if (!phone) return res.status(400).json({ error: 'Phone number is required' });
  const { code } = createOtp(phone, 'patient-login');
  const payload = { ok: true, sentTo: maskTarget(phone) };
  if (process.env.NODE_ENV !== 'production') payload.devOtp = code; // no SMS provider wired up yet — see sendOtp()
  res.json(payload);
});
// Verify the code. If a patient with this phone already exists, log them in;
// otherwise self-register a new patient the same way /patients/self-register
// does, using the phone as their permanent login credential.
app.post('/api/auth/otp/verify', otpLimiter, (req, res) => {
  const phone = (req.body.phone || '').trim();
  const otp = (req.body.otp || '').trim();
  const name = (req.body.name || '').trim();
  if (!phone || !otp) return res.status(400).json({ error: 'Phone number and OTP are required' });
  const result = verifyOtp(phone, 'patient-login', otp);
  if (!result.ok) return res.status(400).json({ error: result.error });

  let row = db.prepare('SELECT * FROM patients WHERE phone=?').get(phone);
  if (!row) {
    const hosp = db.prepare('SELECT id FROM hospitals LIMIT 1').get();
    if (!hosp) return res.status(500).json({ error: 'No hospital available to register under' });
    const id = nextId('patients', 'PT-', 3);
    db.prepare(`INSERT INTO patients (id,name,age,dept,diagnosis,status,hospitalId,doctorId,password,insurance,cost,phone)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`).run(id, name || 'New Patient', null, null, null, 'stable', hosp.id, null, db.hashPassword(phone + '-' + crypto.randomBytes(8).toString('hex')), '', 0, phone);
    notify('admin', `Patient ${name || 'New Patient'} (${id}) self-registered via phone OTP.`);
    broadcast('patients:changed', {});
    row = db.prepare('SELECT * FROM patients WHERE id=?').get(id);
  }
  const token = createSession('patient', row.id, row.hospitalId || null);
  const { password: _pw, ...safe } = row;
  res.json({ token, role: 'patient', user: safe });
});

/* ---- Google Sign-In: verify the ID token server-side, then log in or link a patient account ---- */
app.post('/api/auth/google', loginLimiter, async (req, res) => {
  const { credential } = req.body;
  if (!credential) return res.status(400).json({ error: 'Missing Google credential' });
  let profile;
  try {
    // Google's tokeninfo endpoint validates the token's signature/expiry for us
    // and returns its claims — no extra dependency needed to verify it here.
    const r = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(credential)}`);
    if (!r.ok) return res.status(401).json({ error: 'Invalid Google credential' });
    profile = await r.json();
  } catch (e) {
    return res.status(502).json({ error: 'Could not verify Google credential' });
  }
  const expectedAud = process.env.GOOGLE_CLIENT_ID;
  if (expectedAud && profile.aud !== expectedAud) return res.status(401).json({ error: 'Google credential was not issued for this app' });
  if (profile.email_verified !== 'true' && profile.email_verified !== true) return res.status(401).json({ error: 'Google email is not verified' });

  const googleId = profile.sub;
  const email = (profile.email || '').toLowerCase();
  const name = profile.name || email;

  let row = db.prepare('SELECT * FROM patients WHERE googleId=?').get(googleId)
    || (email ? db.prepare('SELECT * FROM patients WHERE LOWER(email)=?').get(email) : null);

  if (row) {
    if (!row.googleId) db.prepare('UPDATE patients SET googleId=? WHERE id=?').run(googleId, row.id);
  } else {
    const hosp = db.prepare('SELECT id FROM hospitals LIMIT 1').get();
    if (!hosp) return res.status(500).json({ error: 'No hospital available to register under' });
    const id = nextId('patients', 'PT-', 3);
    db.prepare(`INSERT INTO patients (id,name,age,dept,diagnosis,status,hospitalId,doctorId,password,insurance,cost,email,googleId)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(id, name, null, null, null, 'stable', hosp.id, null, db.hashPassword(crypto.randomBytes(16).toString('hex')), '', 0, email, googleId);
    notify('admin', `Patient ${name} (${id}) signed up via Google.`);
    broadcast('patients:changed', {});
  }
  row = db.prepare('SELECT * FROM patients WHERE googleId=?').get(googleId);
  const token = createSession('patient', row.id, row.hospitalId || null);
  const { password: _pw, ...safe } = row;
  res.json({ token, role: 'patient', user: safe });
});

/* ---- Forgot password: any role, via a code sent to the account's phone (patient) or email (staff) ---- */
const ROLE_TABLES = { admin: 'admins', doctor: 'doctors', nurse: 'nurses', patient: 'patients' };
app.post('/api/auth/password/forgot/request', otpLimiter, (req, res) => {
  const { role, id } = req.body;
  const table = ROLE_TABLES[role];
  if (!table || !id) return res.status(400).json({ error: 'Role and account ID/name are required' });
  const row = db.prepare(`SELECT * FROM ${table} WHERE id=? OR LOWER(name)=LOWER(?)`).get(id, id);
  // Same response whether or not the account exists / has a contact on file,
  // so this can't be used to enumerate accounts.
  const generic = { ok: true, message: 'If that account exists and has a phone/email on file, a reset code was sent.' };
  if (!row) return res.json(generic);
  const target = role === 'patient' ? row.phone : row.email;
  if (!target) return res.json(generic);
  const { code } = createOtp(target, 'password-reset', role);
  const payload = { ...generic, sentTo: maskTarget(target) };
  if (process.env.NODE_ENV !== 'production') payload.devOtp = code; // no SMS/email provider wired up yet — see sendOtp()
  res.json(payload);
});
app.post('/api/auth/password/forgot/verify', otpLimiter, (req, res) => {
  const { role, id, otp, newPassword } = req.body;
  const table = ROLE_TABLES[role];
  if (!table || !id || !otp || !newPassword) return res.status(400).json({ error: 'Role, account ID, OTP, and new password are required' });
  if (newPassword.length < 4) return res.status(400).json({ error: 'New password is too short' });
  const row = db.prepare(`SELECT * FROM ${table} WHERE id=? OR LOWER(name)=LOWER(?)`).get(id, id);
  if (!row) return res.status(400).json({ error: 'Invalid OTP' }); // don't confirm account existence here either
  const target = role === 'patient' ? row.phone : row.email;
  if (!target) return res.status(400).json({ error: 'No phone/email on file for this account' });
  const result = verifyOtp(target, 'password-reset', otp);
  if (!result.ok) return res.status(400).json({ error: result.error });
  db.prepare(`UPDATE ${table} SET password=? WHERE id=?`).run(db.hashPassword(newPassword), row.id);
  res.json({ ok: true });
});

// Universal self-service profile edit — every role can update their own photo,
// address, and password. Nothing else (name/ID/clinical fields stay admin- or
// doctor-controlled per role, as already enforced on the dedicated routes below).
app.put('/api/me', auth, (req, res) => {
  const s = req.session;
  const table = { admin: 'admins', doctor: 'doctors', nurse: 'nurses', patient: 'patients' }[s.role];
  const allowed = ['photo', 'address', 'password'];
  const fields = {};
  for (const k of allowed) if (k in req.body && req.body[k] !== '') fields[k] = req.body[k];
  if (fields.password) fields.password = db.hashPassword(fields.password);
  const keys = Object.keys(fields);
  if (keys.length) db.prepare(`UPDATE ${table} SET ${keys.map(k => `${k}=?`).join(',')} WHERE id=?`).run(...keys.map(k => fields[k]), s.id);
  const { password: _pw, ...safe } = db.prepare(`SELECT * FROM ${table} WHERE id=?`).get(s.id);
  res.json({ ok: true, user: safe });
});

/* ================= HOSPITALS ================= */
app.get('/api/hospitals/public', (req, res) => {
  res.json(db.prepare('SELECT id,name,city,address,latitude,longitude FROM hospitals').all());
});
app.get('/api/hospitals', auth, (req, res) => {
  res.json(db.prepare('SELECT * FROM hospitals').all());
});
// IDs below use a max-existing-numeric-suffix+1 scheme rather than COUNT(*)+1:
// COUNT(*) collides with existing IDs once any row has been deleted (e.g. delete
// the newest row, then the next insert regenerates the same ID as one already
// in use elsewhere), and under concurrent requests two inserts can read the
// same COUNT before either commits. Reading the current max suffix avoids both.
function nextId(table, prefix, pad) {
  const rows = db.prepare(`SELECT id FROM ${table} WHERE id LIKE ?`).all(prefix + '%');
  let max = 0;
  for (const r of rows) {
    const n = parseInt(r.id.slice(prefix.length), 10);
    if (!isNaN(n) && n > max) max = n;
  }
  const next = max + 1;
  return prefix + (pad ? String(next).padStart(pad, '0') : String(next));
}

app.post('/api/hospitals', auth, requireRole('admin'), (req, res) => {
  const { name, city, address, latitude, longitude } = req.body;
  const id = nextId('hospitals', 'H-');
  db.prepare('INSERT INTO hospitals (id,name,city,address,latitude,longitude) VALUES (?,?,?,?,?,?)')
    .run(id, name, city || '', address || '', latitude ?? null, longitude ?? null);
  db.prepare('INSERT INTO beds (hospitalId,total,occupied) VALUES (?,0,0)').run(id);
  const groups = ['A+','A-','B+','B-','AB+','AB-','O+','O-'];
  const insBlood = db.prepare('INSERT INTO blood_bank (id,hospitalId,bloodGroup,units) VALUES (?,?,?,0)');
  groups.forEach(g => insBlood.run(`BB-${id}-${g}`, id, g));
  notify('admin', `Hospital "${name}" added to the network.`);
  broadcast('hospitals:changed', {});
  res.json({ id });
});
app.put('/api/hospitals/:id', auth, requireRole('admin'), (req, res) => {
  const allowed = ['name', 'city', 'address', 'latitude', 'longitude'];
  const fields = {};
  for (const k of allowed) if (k in req.body) fields[k] = req.body[k];
  const keys = Object.keys(fields);
  if (keys.length) db.prepare(`UPDATE hospitals SET ${keys.map(k => `${k}=?`).join(',')} WHERE id=?`).run(...keys.map(k => fields[k]), req.params.id);
  broadcast('hospitals:changed', {});
  res.json({ ok: true });
});

/* ================= STAFF DIRECTORY (admin manages doctors & nurses) ================= */
app.get('/api/staff', auth, requireRole('admin', 'nurse'), (req, res) => {
  const doctors = db.prepare('SELECT id,name,hospitalId,specialty FROM doctors').all();
  const nurses = db.prepare('SELECT id,name,hospitalId FROM nurses').all();
  res.json({ doctors, nurses });
});
app.post('/api/staff/doctor', auth, requireRole('admin'), (req, res) => {
  const { name, hospitalId, password, specialty } = req.body;
  const id = nextId('doctors', 'DR-');
  db.prepare('INSERT INTO doctors (id,name,hospitalId,password,specialty) VALUES (?,?,?,?,?)')
    .run(id, name, hospitalId, db.hashPassword(password), specialty || '');
  notify('admin', `Doctor account created for ${name} (${id}).`);
  broadcast('staff:changed', {});
  res.json({ id });
});
app.post('/api/staff/nurse', auth, requireRole('admin'), (req, res) => {
  const { name, hospitalId, password } = req.body;
  const id = nextId('nurses', 'NR-');
  db.prepare('INSERT INTO nurses (id,name,hospitalId,password) VALUES (?,?,?,?)').run(id, name, hospitalId, db.hashPassword(password));
  notify('admin', `Nurse account created for ${name} (${id}).`);
  broadcast('staff:changed', {});
  res.json({ id });
});
// Whitelisted column set — req.body keys must never be used directly as SQL
// identifiers (the old code did `${k}=?` for arbitrary body keys, which was
// both a SQL-injection surface and let a caller overwrite the `id` column).
app.put('/api/staff/:role/:id', auth, requireRole('admin'), (req, res) => {
  const { role, id } = req.params;
  const table = role === 'doctor' ? 'doctors' : 'nurses';
  const allowed = role === 'doctor' ? ['name', 'password', 'hospitalId', 'specialty', 'photo', 'address'] : ['name', 'password', 'hospitalId', 'photo', 'address'];
  const fields = {};
  for (const k of allowed) if (k in req.body) fields[k] = req.body[k];
  if (fields.password) fields.password = db.hashPassword(fields.password);
  const keys = Object.keys(fields);
  if (!keys.length) return res.json({ ok: true });
  db.prepare(`UPDATE ${table} SET ${keys.map(k => `${k}=?`).join(',')} WHERE id=?`).run(...keys.map(k => fields[k]), id);
  broadcast('staff:changed', {});
  res.json({ ok: true });
});
app.delete('/api/staff/:role/:id', auth, requireRole('admin'), (req, res) => {
  const { role, id } = req.params;
  const table = role === 'doctor' ? 'doctors' : 'nurses';
  db.prepare(`DELETE FROM ${table} WHERE id=?`).run(id);
  notify('admin', `${role} account ${id} removed.`);
  broadcast('staff:changed', {});
  res.json({ ok: true });
});

/* ================= PATIENTS ================= */
// Admin: all patients, full CRUD. Doctor: only own patients. Nurse: all patients in own hospital. Patient: only self.
app.get('/api/patients', auth, (req, res) => {
  const s = req.session;
  let rows;
  if (s.role === 'admin') rows = db.prepare('SELECT * FROM patients').all();
  else if (s.role === 'doctor') rows = db.prepare('SELECT * FROM patients WHERE doctorId=?').all(s.id);
  else if (s.role === 'nurse') rows = db.prepare('SELECT * FROM patients WHERE hospitalId=?').all(s.hospitalId);
  else rows = db.prepare('SELECT * FROM patients WHERE id=?').all(s.id);
  res.json(rows.map(({ password, ...rest }) => rest));
});
app.post('/api/patients', auth, requireRole('admin'), (req, res) => {
  const { name, age, dept, diagnosis, status, hospitalId, doctorId, password, insurance, cost, gender, bloodGroup, contactNumber, emergencyContact } = req.body;
  const id = nextId('patients', 'PT-', 3);
  db.prepare(`INSERT INTO patients (id,name,age,dept,diagnosis,status,hospitalId,doctorId,password,insurance,cost,gender,bloodGroup,contactNumber,emergencyContact)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(id, name, age, dept, diagnosis, status || 'stable', hospitalId, doctorId, db.hashPassword(password), insurance || '', cost || 0, gender || '', bloodGroup || '', contactNumber || '', emergencyContact || '');
  notify('admin', `Patient ${name} (${id}) added with portal access.`);
  notify(`doctor:${doctorId}`, `New patient ${name} (${id}) assigned to you.`);
  broadcast('patients:changed', {});
  res.json({ id });
});
// Public: patient self-registration from the login screen (no admin needed).
// Leaving Patient ID blank on the login form hits this route; the phone number
// doubles as the patient's login credential from then on.
app.post('/api/patients/self-register', (req, res) => {
  const { name, phone } = req.body;
  if (!name || !phone) return res.status(400).json({ error: 'Full name and phone number are required' });
  const hosp = db.prepare('SELECT id FROM hospitals LIMIT 1').get();
  if (!hosp) return res.status(500).json({ error: 'No hospital available to register under' });

  const id = nextId('patients', 'PT-', 3);
  // `password` is stored hashed (phone doubles as the login password here);
  // `phone` itself stays plaintext since it's also used as the separate
  // extraPasswordCol alternate-credential check in findAccount().
  db.prepare(`INSERT INTO patients (id,name,age,dept,diagnosis,status,hospitalId,doctorId,password,insurance,cost,phone)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`).run(id, name, null, null, null, 'stable', hosp.id, null, db.hashPassword(phone), '', 0, phone);
  notify('admin', `Patient ${name} (${id}) self-registered via the portal.`);
  broadcast('patients:changed', {});

  const token = createSession('patient', id, hosp.id);
  const { password: _pw, ...safe } = db.prepare('SELECT * FROM patients WHERE id=?').get(id);
  res.json({ token, role: 'patient', user: safe });
});

app.put('/api/patients/:id', auth, requireRole('admin', 'nurse', 'doctor'), (req, res) => {
  const { id } = req.params;
  const s = req.session;
  const patient = db.prepare('SELECT * FROM patients WHERE id=?').get(id);
  if (!patient) return res.status(404).json({ error: 'Not found' });
  if (s.role === 'doctor' && patient.doctorId !== s.id) return res.status(403).json({ error: 'Not your patient' });
  if (s.role === 'nurse' && patient.hospitalId !== s.hospitalId) return res.status(403).json({ error: 'Different hospital' });

  const allowed = s.role === 'admin'
    ? ['name', 'age', 'dept', 'diagnosis', 'status', 'hospitalId', 'doctorId', 'password', 'insurance', 'cost', 'report', 'gender', 'bloodGroup', 'contactNumber', 'emergencyContact', 'photo', 'address']
    : ['status', 'diagnosis']; // doctor/nurse can only update clinical fields; everything else is admin-only
  const fields = {};
  for (const k of allowed) if (k in req.body) fields[k] = req.body[k];
  if (fields.password) fields.password = db.hashPassword(fields.password);
  const keys = Object.keys(fields);
  if (keys.length) {
    db.prepare(`UPDATE patients SET ${keys.map(k => `${k}=?`).join(',')} WHERE id=?`).run(...keys.map(k => fields[k]), id);
  }
  notify(`patient:${id}`, `Your record was updated by ${s.role} ${s.id}.`);
  broadcast('patients:changed', {});
  res.json({ ok: true });
});
app.delete('/api/patients/:id', auth, requireRole('admin'), (req, res) => {
  db.prepare('DELETE FROM patients WHERE id=?').run(req.params.id);
  notify('admin', `Patient record ${req.params.id} removed.`);
  broadcast('patients:changed', {});
  res.json({ ok: true });
});

/* ================= EQUIPMENT / EMERGENCY READINESS ================= */
app.get('/api/equipment', auth, (req, res) => {
  const s = req.session;
  let hospitalId = req.query.hospitalId;
  if (s.role === 'nurse' || s.role === 'doctor') hospitalId = s.hospitalId;
  const rows = hospitalId
    ? db.prepare('SELECT * FROM equipment WHERE hospitalId=?').all(hospitalId)
    : db.prepare('SELECT * FROM equipment').all();
  res.json(rows);
});
app.put('/api/equipment/:id', auth, requireRole('admin', 'nurse'), (req, res) => {
  const { available, total } = req.body;
  const fields = {};
  if (available !== undefined) fields.available = available;
  if (total !== undefined) fields.total = total;
  const keys = Object.keys(fields);
  if (keys.length) db.prepare(`UPDATE equipment SET ${keys.map(k => `${k}=?`).join(',')} WHERE id=?`).run(...keys.map(k => fields[k]), req.params.id);
  broadcast('equipment:changed', {});
  res.json({ ok: true });
});

app.get('/api/beds', auth, (req, res) => {
  res.json(db.prepare('SELECT * FROM beds').all());
});
app.put('/api/beds/:hospitalId', auth, requireRole('admin', 'nurse'), (req, res) => {
  const { occupied, total } = req.body;
  const fields = {};
  if (occupied !== undefined) fields.occupied = occupied;
  if (total !== undefined) fields.total = total;
  const keys = Object.keys(fields);
  if (keys.length) db.prepare(`UPDATE beds SET ${keys.map(k => `${k}=?`).join(',')} WHERE hospitalId=?`).run(...keys.map(k => fields[k]), req.params.hospitalId);
  broadcast('beds:changed', {});
  res.json({ ok: true });
});

/* ================= BLOOD AVAILABILITY ================= */
app.get('/api/blood', auth, (req, res) => {
  const s = req.session;
  let hospitalId = req.query.hospitalId;
  if (s.role === 'nurse' || s.role === 'doctor') hospitalId = s.hospitalId;
  const rows = hospitalId
    ? db.prepare('SELECT * FROM blood_bank WHERE hospitalId=?').all(hospitalId)
    : db.prepare('SELECT * FROM blood_bank').all();
  res.json(rows);
});
// Public read — patients and unauthenticated visitors (e.g. from the SOS flow) can check availability before a login.
app.get('/api/blood/public', (req, res) => {
  const rows = db.prepare('SELECT hospitalId,bloodGroup,units FROM blood_bank').all();
  res.json(rows);
});
app.put('/api/blood/:id', auth, requireRole('admin', 'nurse'), (req, res) => {
  const { units } = req.body;
  db.prepare('UPDATE blood_bank SET units=? WHERE id=?').run(units, req.params.id);
  const row = db.prepare('SELECT * FROM blood_bank WHERE id=?').get(req.params.id);
  if (row && row.units <= 3) notify('admin', `Low blood stock: ${row.bloodGroup} at ${row.hospitalId} down to ${row.units} units.`);
  broadcast('blood:changed', {});
  res.json({ ok: true });
});

/* ================= ORGAN DONATION ================= */
app.get('/api/organs', auth, (req, res) => {
  const s = req.session;
  let hospitalId = req.query.hospitalId;
  if (s.role === 'nurse' || s.role === 'doctor') hospitalId = s.hospitalId;
  const rows = hospitalId
    ? db.prepare('SELECT * FROM organ_bank WHERE hospitalId=?').all(hospitalId)
    : db.prepare('SELECT * FROM organ_bank').all();
  res.json(rows);
});
// Public read — same rationale as /api/blood/public: visible before login.
app.get('/api/organs/public', (req, res) => {
  const rows = db.prepare('SELECT hospitalId,organ,required,pledged FROM organ_bank').all();
  res.json(rows);
});
// Only Hospital Admin (and nurses, who run the ward-level waitlist day to day) can set
// how many organs a hospital requires or how many pledges it currently has.
app.put('/api/organs/:id', auth, requireRole('admin', 'nurse'), (req, res) => {
  const row = db.prepare('SELECT * FROM organ_bank WHERE id=?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Not found' });
  const required = 'required' in req.body ? +req.body.required : row.required;
  const pledged = 'pledged' in req.body ? +req.body.pledged : row.pledged;
  db.prepare('UPDATE organ_bank SET required=?, pledged=? WHERE id=?').run(required, pledged, req.params.id);
  if (required > pledged) notify('admin', `Organ shortfall: ${row.organ} at ${row.hospitalId} needs ${required - pledged} more pledge(s).`);
  broadcast('organs:changed', {});
  res.json({ ok: true });
});

// Patient self-service: register/withdraw as an organ donor. Only the logged-in
// patient can flip their own pledge — not an admin/nurse/doctor editing someone else.
app.put('/api/patients/:id/donor-pledge', auth, requireRole('patient'), (req, res) => {
  const s = req.session;
  if (s.id !== req.params.id) return res.status(403).json({ error: 'You can only update your own donor status' });
  const isDonor = req.body.isDonor ? 1 : 0;
  db.prepare('UPDATE patients SET isDonor=? WHERE id=?').run(isDonor, req.params.id);
  broadcast('patients:changed', {});
  res.json({ ok: true, isDonor: !!isDonor });
});

/* ================= BLOOD DONATION (patient screening intake → nurse/admin approval) =================
 * Whiteboard spec: patient fills the donor screening form (full name/ID, age
 * 18-65, weight, haemoglobin, BP, pulse, blood group *required*, optional
 * past-report image, and a date/time for the donation appointment). A nurse
 * or admin reviews it and marks it completed once the donation actually
 * happens, at which point: (1) the patient's name shows up on the admin
 * dashboard, and (2) the hospital's blood bank stock ticks up by one unit.
 */
app.get('/api/blood-donations', auth, (req, res) => {
  const s = req.session;
  let rows;
  if (s.role === 'admin') rows = db.prepare('SELECT * FROM blood_donations ORDER BY createdAt DESC').all();
  else if (s.role === 'nurse' || s.role === 'doctor') rows = db.prepare('SELECT * FROM blood_donations WHERE hospitalId=? ORDER BY createdAt DESC').all(s.hospitalId);
  else rows = db.prepare('SELECT * FROM blood_donations WHERE patientId=? ORDER BY createdAt DESC').all(s.id);
  res.json(rows.map(r => ({ ...r, reportImage: r.reportImage ? true : false, reportImageUrl: r.reportImage || null })));
});
app.post('/api/blood-donations', auth, requireRole('patient'), (req, res) => {
  const s = req.session;
  const { fullName, age, weight, hemoglobin, bloodPressure, pulseRate, bloodGroup, reportImage, appointmentDate, appointmentTime, notes } = req.body;
  if (!fullName || !bloodGroup) return res.status(400).json({ error: 'Full name and blood group are required' });
  const ageNum = +age;
  if (!ageNum || ageNum < 18 || ageNum > 65) return res.status(400).json({ error: 'Donor age must be between 18 and 65' });
  if (!appointmentDate || !appointmentTime) return res.status(400).json({ error: 'Please choose a date and time for the donation appointment' });
  const hospitalId = s.hospitalId || (db.prepare('SELECT id FROM hospitals LIMIT 1').get() || {}).id;
  const id = 'BD-' + Date.now();
  const storedReport = saveUserFile('patient', s.id, 'donor-report', reportImage);
  db.prepare(`INSERT INTO blood_donations (id,patientId,hospitalId,fullName,age,weight,hemoglobin,bloodPressure,pulseRate,bloodGroup,reportImage,appointmentDate,appointmentTime,status,notes,createdAt)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
    .run(id, s.id, hospitalId, fullName, ageNum, weight || null, hemoglobin || '', bloodPressure || '', pulseRate || '', bloodGroup, storedReport, appointmentDate, appointmentTime, 'pending', notes || '', new Date().toISOString());
  notify('admin', `${fullName} (${s.id}) submitted a blood donation appointment for ${appointmentDate} ${appointmentTime}.`);
  notify(`hospital:${hospitalId}`, `New blood donor screening from ${fullName} — appointment ${appointmentDate} ${appointmentTime}.`);
  broadcast('blood-donations:changed', {});
  res.json({ id });
});
app.put('/api/blood-donations/:id', auth, requireRole('admin', 'nurse'), (req, res) => {
  const row = db.prepare('SELECT * FROM blood_donations WHERE id=?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Not found' });
  if (req.session.role === 'nurse' && row.hospitalId !== req.session.hospitalId) return res.status(403).json({ error: 'Different hospital' });
  const { status, notes } = req.body;
  const allowedStatus = ['pending', 'approved', 'completed', 'rejected'];
  if (status && !allowedStatus.includes(status)) return res.status(400).json({ error: 'Invalid status' });
  db.prepare('UPDATE blood_donations SET status=COALESCE(?,status), notes=COALESCE(?,notes) WHERE id=?').run(status || null, notes ?? null, req.params.id);

  if (status === 'completed' && row.status !== 'completed') {
    // Successful donation: bump the hospital's stock for that blood group and
    // surface the donor's name on the admin dashboard, per the whiteboard spec.
    const bb = db.prepare('SELECT * FROM blood_bank WHERE hospitalId=? AND bloodGroup=?').get(row.hospitalId, row.bloodGroup);
    if (bb) db.prepare('UPDATE blood_bank SET units=units+1 WHERE id=?').run(bb.id);
    notify('admin', `🩸 ${row.fullName} (${row.patientId}) successfully donated blood (${row.bloodGroup}) at ${hospName_(row.hospitalId)}.`);
    broadcast('blood:changed', {});
  } else if (status === 'rejected') {
    notify(`patient:${row.patientId}`, `Your blood donation appointment was not approved. ${notes ? 'Note: ' + notes : ''}`);
  } else if (status === 'approved') {
    notify(`patient:${row.patientId}`, `Your blood donation appointment on ${row.appointmentDate} ${row.appointmentTime} is confirmed.`);
  }
  broadcast('blood-donations:changed', {});
  res.json({ ok: true });
});
function hospName_(id) { const h = db.prepare('SELECT name FROM hospitals WHERE id=?').get(id); return h ? h.name : id; }

/* ================= MEDICINE ALARMS (nurse-set reminders for post-op patients) ================= */
app.get('/api/medicine-alarms', auth, (req, res) => {
  const s = req.session;
  const patientId = req.query.patientId || (s.role === 'patient' ? s.id : null);
  let rows;
  if (s.role === 'patient') rows = db.prepare('SELECT * FROM medicine_alarms WHERE patientId=? AND active=1 ORDER BY createdAt DESC').all(s.id);
  else if (s.role === 'nurse') rows = patientId
    ? db.prepare('SELECT * FROM medicine_alarms WHERE patientId=? AND hospitalId=? ORDER BY createdAt DESC').all(patientId, s.hospitalId)
    : db.prepare('SELECT * FROM medicine_alarms WHERE hospitalId=? ORDER BY createdAt DESC').all(s.hospitalId);
  else if (s.role === 'admin') rows = db.prepare('SELECT * FROM medicine_alarms ORDER BY createdAt DESC').all();
  else return res.status(403).json({ error: 'Forbidden for this role' });
  res.json(rows.map(r => ({ ...r, times: JSON.parse(r.times || '[]') })));
});
app.post('/api/medicine-alarms', auth, requireRole('nurse'), (req, res) => {
  const s = req.session;
  const { patientId, medicineName, times, startDate, endDate, notes } = req.body;
  if (!patientId || !medicineName || !Array.isArray(times) || !times.length) return res.status(400).json({ error: 'Patient, medicine name, and at least one reminder time are required' });
  const patient = db.prepare('SELECT * FROM patients WHERE id=?').get(patientId);
  if (!patient) return res.status(404).json({ error: 'Patient not found' });
  if (patient.hospitalId !== s.hospitalId) return res.status(403).json({ error: 'Different hospital' });
  const id = 'ALM-' + Date.now();
  db.prepare(`INSERT INTO medicine_alarms (id,patientId,nurseId,hospitalId,medicineName,times,startDate,endDate,notes,active,createdAt)
    VALUES (?,?,?,?,?,?,?,?,?,1,?)`)
    .run(id, patientId, s.id, s.hospitalId, medicineName, JSON.stringify(times), startDate || null, endDate || null, notes || '', new Date().toISOString());
  notify(`patient:${patientId}`, `Nurse ${s.id} set a medicine reminder for ${medicineName} at ${times.join(', ')}.`);
  broadcast('medicine-alarms:changed', {});
  res.json({ id });
});
app.put('/api/medicine-alarms/:id', auth, requireRole('nurse'), (req, res) => {
  const row = db.prepare('SELECT * FROM medicine_alarms WHERE id=?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Not found' });
  if (row.hospitalId !== req.session.hospitalId) return res.status(403).json({ error: 'Different hospital' });
  const allowed = ['medicineName', 'startDate', 'endDate', 'notes', 'active'];
  const fields = {};
  for (const k of allowed) if (k in req.body) fields[k] = req.body[k];
  if ('times' in req.body && Array.isArray(req.body.times)) fields.times = JSON.stringify(req.body.times);
  const keys = Object.keys(fields);
  if (keys.length) db.prepare(`UPDATE medicine_alarms SET ${keys.map(k => `${k}=?`).join(',')} WHERE id=?`).run(...keys.map(k => fields[k]), req.params.id);
  broadcast('medicine-alarms:changed', {});
  res.json({ ok: true });
});
app.delete('/api/medicine-alarms/:id', auth, requireRole('nurse'), (req, res) => {
  const row = db.prepare('SELECT * FROM medicine_alarms WHERE id=?').get(req.params.id);
  if (row && row.hospitalId !== req.session.hospitalId) return res.status(403).json({ error: 'Different hospital' });
  db.prepare('DELETE FROM medicine_alarms WHERE id=?').run(req.params.id);
  broadcast('medicine-alarms:changed', {});
  res.json({ ok: true });
});

/* ================= PRESCRIPTIONS (doctor writes text, or attaches photos that get read for the patient) =================
 * If ANTHROPIC_API_KEY is set, uploaded photos are sent to Claude's vision
 * API to transcribe the handwriting/printout and reformat it into a clean,
 * patient-readable medicine list. Without a key, photos are still saved and
 * shown to the patient — just without the automatic clean-format read-out.
 */
async function analyzePrescriptionPhotos(photoDataUrls) {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey || !photoDataUrls.length) return null;
  try {
    const content = [
      { type: 'text', text: 'These are photo(s) of a doctor\'s handwritten or printed prescription. Read them carefully and reformat what you find into a clean, plain-language list for the patient: medicine name, dosage, and how/when to take it, one per line. If a word is illegible, say "(unclear)" rather than guessing. Do not add medicines that are not shown in the photo.' }
    ];
    for (const dataUrl of photoDataUrls.slice(0, 6)) {
      const m = dataUrl.match(/^data:([^;]+);base64,(.+)$/);
      if (!m) continue;
      content.push({ type: 'image', source: { type: 'base64', media_type: m[1], data: m[2] } });
    }
    if (content.length === 1) return null; // no valid images decoded
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: 'claude-sonnet-4-6', max_tokens: 800, messages: [{ role: 'user', content }] })
    });
    if (!r.ok) { console.error('[prescription OCR] Anthropic API error', r.status, await r.text().catch(()=>'')); return null; }
    const data = await r.json();
    return (data.content || []).filter(b => b.type === 'text').map(b => b.text).join('\n').trim() || null;
  } catch (e) {
    console.error('[prescription OCR] failed:', e.message);
    return null;
  }
}
app.get('/api/prescriptions', auth, (req, res) => {
  const s = req.session;
  const patientId = req.query.patientId || (s.role === 'patient' ? s.id : null);
  if (!patientId) return res.status(400).json({ error: 'patientId required' });
  const check = canTouchPatientRecord(s, patientId);
  if (!check.ok) return res.status(check.code).json({ error: check.error });
  const rows = db.prepare('SELECT * FROM prescriptions WHERE patientId=? ORDER BY createdAt DESC').all(patientId);
  res.json(rows.map(r => ({ ...r, photos: JSON.parse(r.photos || '[]') })));
});
app.post('/api/prescriptions', auth, requireRole('doctor'), async (req, res) => {
  const s = req.session;
  const { patientId, text, photos } = req.body;
  if (!patientId || (!text && !(Array.isArray(photos) && photos.length))) return res.status(400).json({ error: 'Provide prescription text or at least one photo' });
  const check = canTouchPatientRecord(s, patientId);
  if (!check.ok) return res.status(check.code).json({ error: check.error });
  const storedPhotos = saveUserFiles('patient', patientId, 'prescription', photos || []);
  const extractedText = await analyzePrescriptionPhotos(Array.isArray(photos) ? photos : []);
  const id = 'RX-' + Date.now();
  db.prepare('INSERT INTO prescriptions (id,patientId,doctorId,text,photos,extractedText,createdAt) VALUES (?,?,?,?,?,?,?)')
    .run(id, patientId, s.id, text || '', JSON.stringify(storedPhotos), extractedText, new Date().toISOString());
  notify(`patient:${patientId}`, `Your doctor added a new prescription.${extractedText ? ' It includes a clean, readable medicine list.' : ''}`);
  broadcast('prescriptions:changed', {});
  res.json({ id, extractedText });
});
app.delete('/api/prescriptions/:id', auth, requireRole('doctor'), (req, res) => {
  const row = db.prepare('SELECT * FROM prescriptions WHERE id=?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Not found' });
  if (row.doctorId !== req.session.id) return res.status(403).json({ error: 'Only the prescribing doctor can remove this' });
  db.prepare('DELETE FROM prescriptions WHERE id=?').run(req.params.id);
  broadcast('prescriptions:changed', {});
  res.json({ ok: true });
});

// Patient self-service: save the trusted ambulance contact "Quick SOS" should
// call directly, instead of only looking one up from the hospital fleet.
app.put('/api/patients/:id/ambulance-preference', auth, requireRole('patient'), (req, res) => {
  const s = req.session;
  if (s.id !== req.params.id) return res.status(403).json({ error: 'You can only update your own emergency contact' });
  const { name, contact } = req.body;
  if (!contact) return res.status(400).json({ error: 'An ambulance contact number is required' });
  db.prepare('UPDATE patients SET preferredAmbulanceName=?, preferredAmbulanceContact=? WHERE id=?').run(name || '', contact, s.id);
  broadcast('patients:changed', {});
  res.json({ ok: true });
});

/* ================= APPOINTMENTS ================= */
app.get('/api/appointments', auth, (req, res) => {
  const s = req.session;
  let rows;
  if (s.role === 'admin') rows = db.prepare('SELECT * FROM appointments').all();
  else if (s.role === 'doctor') rows = db.prepare('SELECT * FROM appointments WHERE doctorId=?').all(s.id);
  else if (s.role === 'nurse') rows = db.prepare('SELECT * FROM appointments WHERE hospitalId=?').all(s.hospitalId);
  else rows = db.prepare('SELECT * FROM appointments WHERE patientId=?').all(s.id);
  res.json(rows);
});
app.post('/api/appointments', auth, (req, res) => {
  const s = req.session;
  let { patientId, doctorId, hospitalId, date, reason } = req.body;
  if (s.role === 'patient') patientId = s.id; // patients may only book for themselves
  if (s.role === 'nurse') hospitalId = s.hospitalId; // nurse may only add for own hospital
  const id = 'AP-' + Date.now();
  db.prepare('INSERT INTO appointments (id,patientId,doctorId,hospitalId,date,reason,status) VALUES (?,?,?,?,?,?,?)')
    .run(id, patientId, doctorId || null, hospitalId, date, reason || '', 'pending');
  if (doctorId) notify(`doctor:${doctorId}`, `New appointment request from ${patientId} on ${date}.`);
  notify(`patient:${patientId}`, `Appointment requested for ${date}.`);
  broadcast('appointments:changed', {});
  res.json({ id });
});
// `date` lets a busy doctor propose the next available slot instead of just
// cancelling — status becomes "rescheduled" and the patient is notified of
// the new date/time (per the whiteboard: "if the doctor is busy ... he can
// add the slot of the next date and time").
app.put('/api/appointments/:id', auth, requireRole('admin', 'doctor', 'nurse'), (req, res) => {
  const { status, date, reason } = req.body;
  const existing = db.prepare('SELECT * FROM appointments WHERE id=?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Not found' });
  if (req.session.role === 'doctor' && existing.doctorId !== req.session.id) return res.status(403).json({ error: 'Not your appointment' });
  const nextStatus = date && !status ? 'rescheduled' : status;
  const fields = {};
  if (nextStatus) fields.status = nextStatus;
  if (date) fields.date = date;
  if (reason !== undefined) fields.reason = reason;
  const keys = Object.keys(fields);
  if (keys.length) db.prepare(`UPDATE appointments SET ${keys.map(k => `${k}=?`).join(',')} WHERE id=?`).run(...keys.map(k => fields[k]), req.params.id);
  const appt = db.prepare('SELECT * FROM appointments WHERE id=?').get(req.params.id);
  if (appt) {
    if (date) notify(`patient:${appt.patientId}`, `Your doctor was unavailable and proposed a new slot: ${date}${appt.status==='rescheduled'?'':' — status: '+appt.status}.`);
    else notify(`patient:${appt.patientId}`, `Your appointment on ${appt.date} is now "${appt.status}".`);
  }
  broadcast('appointments:changed', {});
  res.json({ ok: true });
});

/* ================= NOTIFICATIONS ================= */
app.get('/api/notifications', auth, (req, res) => {
  const s = req.session;
  const mine = [`${s.role}:${s.id}`, s.role, s.hospitalId ? `hospital:${s.hospitalId}` : null].filter(Boolean);
  const placeholders = mine.map(() => '?').join(',');
  const rows = db.prepare(`SELECT * FROM notifications WHERE audience IN (${placeholders}) ORDER BY createdAt DESC LIMIT 50`).all(...mine);
  res.json(rows);
});

/* ================= SOS ("Quick SOS" — public, but personalized when the caller is a logged-in patient) =================
 * Per the whiteboard: one tap should reach the nearest hospital and an
 * ambulance directly, drop a Google Maps pin for the location, and surface
 * the contact number of the ambulance *the patient themselves added* (their
 * preferredAmbulance*), not just whatever's in the hospital fleet.
 */
app.post('/api/sos', sosLimiter, optionalAuth, (req, res) => {
  let { name, phone, reason, hospitalId, latitude, longitude } = req.body;
  const patient = (req.session && req.session.role === 'patient')
    ? db.prepare('SELECT * FROM patients WHERE id=?').get(req.session.id) : null;
  if (patient) {
    name = name || patient.name;
    phone = phone || patient.contactNumber || patient.phone;
  }
  if (!phone) return res.status(400).json({ error: 'Phone number is required so responders can reach you' });

  // Auto-pick nearest hospital by GPS if the caller didn't choose one.
  let hospital = hospitalId ? db.prepare('SELECT * FROM hospitals WHERE id=?').get(hospitalId) : null;
  if (!hospital && latitude != null && longitude != null) hospital = nearestHospital(latitude, longitude);
  hospitalId = hospital ? hospital.id : (hospitalId || null);

  // Ambulance to dispatch: the patient's own saved contact takes priority
  // ("the ambulance he added"); otherwise fall back to an available one from
  // the target hospital's fleet.
  let ambulanceName = patient && patient.preferredAmbulanceName ? patient.preferredAmbulanceName : null;
  let ambulanceContact = patient && patient.preferredAmbulanceContact ? patient.preferredAmbulanceContact : null;
  if (!ambulanceContact && hospitalId) {
    const fleet = db.prepare(`SELECT * FROM ambulances WHERE hospitalId=? AND status='available' LIMIT 1`).get(hospitalId);
    if (fleet) { ambulanceName = fleet.driverName ? `${fleet.vehicleNo} (${fleet.driverName})` : fleet.vehicleNo; ambulanceContact = fleet.contact; }
  }

  const id = 'SOS-' + Date.now();
  db.prepare(`INSERT INTO sos_alerts (id,name,phone,reason,hospitalId,latitude,longitude,createdAt,status,ambulanceName,ambulanceContact)
    VALUES (?,?,?,?,?,?,?,?,'open',?,?)`)
    .run(id, name || 'Unknown', phone, reason || '', hospitalId, latitude ?? null, longitude ?? null, new Date().toISOString(), ambulanceName, ambulanceContact);
  const msg = `SOS from ${name || 'an unidentified caller'} (${phone})${reason ? ' — ' + reason : ''}${hospital ? ` — routed to ${hospital.name}` : ''}.`;
  notify('admin', msg);
  if (hospitalId) notify(`hospital:${hospitalId}`, msg);
  broadcast('sos', { id, name, phone, reason, hospitalId, latitude, longitude, ambulanceName, ambulanceContact, createdAt: new Date().toISOString() });
  res.json({
    id, ok: true,
    hospital: hospital ? { id: hospital.id, name: hospital.name, address: hospital.address, latitude: hospital.latitude, longitude: hospital.longitude, distanceKm: hospital.distanceKm } : null,
    ambulanceName, ambulanceContact,
    mapUrl: (latitude != null && longitude != null) ? `https://www.google.com/maps?q=${latitude},${longitude}` : null
  });
});
app.get('/api/sos', auth, requireRole('admin', 'nurse'), (req, res) => {
  res.json(db.prepare('SELECT * FROM sos_alerts ORDER BY createdAt DESC LIMIT 100').all());
});
app.put('/api/sos/:id', auth, requireRole('admin', 'nurse'), (req, res) => {
  const { status } = req.body;
  db.prepare('UPDATE sos_alerts SET status=? WHERE id=?').run(status, req.params.id);
  broadcast('sos:changed', {});
  res.json({ ok: true });
});

/* ================= HEALTH RECORDS (doctor writes, own patients only) ================= */
function canTouchPatientRecord(s, patientId) {
  const patient = db.prepare('SELECT * FROM patients WHERE id=?').get(patientId);
  if (!patient) return { ok: false, code: 404, error: 'Patient not found' };
  if (s.role === 'doctor' && patient.doctorId !== s.id) return { ok: false, code: 403, error: 'Not your patient' };
  if (s.role === 'patient' && s.id !== patientId) return { ok: false, code: 403, error: 'Not your record' };
  // Nurses are scoped to their own hospital everywhere else (patients, ambulances,
  // blood, organs, equipment) — health records/medicines/diet-plan were missing
  // this check, letting a nurse pull any patient's clinical data across hospitals.
  if (s.role === 'nurse' && patient.hospitalId !== s.hospitalId) return { ok: false, code: 403, error: 'Different hospital' };
  return { ok: true, patient };
}
app.get('/api/health-records', auth, (req, res) => {
  const s = req.session;
  const patientId = req.query.patientId || (s.role === 'patient' ? s.id : null);
  if (!patientId) return res.status(400).json({ error: 'patientId required' });
  const check = canTouchPatientRecord(s, patientId);
  if (!check.ok) return res.status(check.code).json({ error: check.error });
  res.json(db.prepare('SELECT * FROM health_records WHERE patientId=? ORDER BY createdAt DESC').all(patientId));
});
app.post('/api/health-records', auth, requireRole('doctor'), (req, res) => {
  const s = req.session;
  const { patientId, note } = req.body;
  if (!note) return res.status(400).json({ error: 'Note is required' });
  const check = canTouchPatientRecord(s, patientId);
  if (!check.ok) return res.status(check.code).json({ error: check.error });
  const id = 'HR-' + Date.now();
  db.prepare('INSERT INTO health_records (id,patientId,doctorId,note,createdAt) VALUES (?,?,?,?,?)')
    .run(id, patientId, s.id, note, new Date().toISOString());
  notify(`patient:${patientId}`, `Your doctor added a new health record entry.`);
  broadcast('health-records:changed', {});
  res.json({ id });
});
app.delete('/api/health-records/:id', auth, requireRole('doctor'), (req, res) => {
  const row = db.prepare('SELECT * FROM health_records WHERE id=?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Not found' });
  if (row.doctorId !== req.session.id) return res.status(403).json({ error: 'Only the doctor who wrote this entry can remove it' });
  db.prepare('DELETE FROM health_records WHERE id=?').run(req.params.id);
  broadcast('health-records:changed', {});
  res.json({ ok: true });
});

/* ================= DIET PLAN (one per patient, doctor-owned) ================= */
app.get('/api/diet-plan/:patientId', auth, (req, res) => {
  const check = canTouchPatientRecord(req.session, req.params.patientId);
  if (!check.ok) return res.status(check.code).json({ error: check.error });
  const row = db.prepare('SELECT * FROM diet_plans WHERE patientId=?').get(req.params.patientId);
  res.json(row || { patientId: req.params.patientId, text: '', doctorId: null, updatedAt: null });
});
app.put('/api/diet-plan/:patientId', auth, requireRole('doctor'), (req, res) => {
  const s = req.session;
  const check = canTouchPatientRecord(s, req.params.patientId);
  if (!check.ok) return res.status(check.code).json({ error: check.error });
  const { text } = req.body;
  const now = new Date().toISOString();
  const existing = db.prepare('SELECT * FROM diet_plans WHERE patientId=?').get(req.params.patientId);
  if (existing) db.prepare('UPDATE diet_plans SET text=?, doctorId=?, updatedAt=? WHERE patientId=?').run(text || '', s.id, now, req.params.patientId);
  else db.prepare('INSERT INTO diet_plans (patientId,doctorId,text,updatedAt) VALUES (?,?,?,?)').run(req.params.patientId, s.id, text || '', now);
  notify(`patient:${req.params.patientId}`, `Your diet plan was updated.`);
  broadcast('diet:changed', {});
  res.json({ ok: true });
});

/* ================= MEDICINES (prescribed by, and editable only by, the owning doctor) ================= */
app.get('/api/medicines', auth, (req, res) => {
  const s = req.session;
  const patientId = req.query.patientId || (s.role === 'patient' ? s.id : null);
  if (!patientId) return res.status(400).json({ error: 'patientId required' });
  const check = canTouchPatientRecord(s, patientId);
  if (!check.ok) return res.status(check.code).json({ error: check.error });
  res.json(db.prepare('SELECT * FROM medicines WHERE patientId=? ORDER BY createdAt DESC').all(patientId));
});
app.post('/api/medicines', auth, requireRole('doctor'), (req, res) => {
  const s = req.session;
  const { patientId, name, dosage, instructions } = req.body;
  if (!name) return res.status(400).json({ error: 'Medicine name is required' });
  const check = canTouchPatientRecord(s, patientId);
  if (!check.ok) return res.status(check.code).json({ error: check.error });
  const id = 'MED-' + Date.now();
  db.prepare('INSERT INTO medicines (id,patientId,doctorId,name,dosage,instructions,createdAt) VALUES (?,?,?,?,?,?,?)')
    .run(id, patientId, s.id, name, dosage || '', instructions || '', new Date().toISOString());
  notify(`patient:${patientId}`, `Your doctor prescribed ${name}.`);
  broadcast('medicines:changed', {});
  res.json({ id });
});
app.delete('/api/medicines/:id', auth, requireRole('doctor'), (req, res) => {
  const row = db.prepare('SELECT * FROM medicines WHERE id=?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Not found' });
  if (row.doctorId !== req.session.id) return res.status(403).json({ error: 'Only the prescribing doctor can remove this' });
  db.prepare('DELETE FROM medicines WHERE id=?').run(req.params.id);
  broadcast('medicines:changed', {});
  res.json({ ok: true });
});

/* ================= AMBULANCES (admin CRUD, own hospital; everyone else reads) ================= */
app.get('/api/ambulances', auth, (req, res) => {
  const s = req.session;
  let hospitalId = req.query.hospitalId;
  if (s.role === 'nurse' || s.role === 'doctor') hospitalId = s.hospitalId;
  const rows = hospitalId
    ? db.prepare('SELECT * FROM ambulances WHERE hospitalId=?').all(hospitalId)
    : db.prepare('SELECT * FROM ambulances').all();
  res.json(rows);
});
app.post('/api/ambulances', auth, requireRole('admin'), (req, res) => {
  const { hospitalId, vehicleNo, driverName, contact, status } = req.body;
  if (!hospitalId || !vehicleNo) return res.status(400).json({ error: 'Hospital and vehicle number are required' });
  const id = 'AMB-' + Date.now();
  db.prepare('INSERT INTO ambulances (id,hospitalId,vehicleNo,driverName,contact,status) VALUES (?,?,?,?,?,?)')
    .run(id, hospitalId, vehicleNo, driverName || '', contact || '', status || 'available');
  broadcast('ambulances:changed', {});
  res.json({ id });
});
app.put('/api/ambulances/:id', auth, requireRole('admin'), (req, res) => {
  const allowed = ['vehicleNo', 'driverName', 'contact', 'status'];
  const fields = {};
  for (const k of allowed) if (k in req.body) fields[k] = req.body[k];
  const keys = Object.keys(fields);
  if (keys.length) db.prepare(`UPDATE ambulances SET ${keys.map(k => `${k}=?`).join(',')} WHERE id=?`).run(...keys.map(k => fields[k]), req.params.id);
  broadcast('ambulances:changed', {});
  res.json({ ok: true });
});
app.delete('/api/ambulances/:id', auth, requireRole('admin'), (req, res) => {
  db.prepare('DELETE FROM ambulances WHERE id=?').run(req.params.id);
  broadcast('ambulances:changed', {});
  res.json({ ok: true });
});

/* ================= DISEASES (admin CRUD; everyone else reads) ================= */
app.get('/api/diseases', auth, (req, res) => {
  const s = req.session;
  let hospitalId = req.query.hospitalId;
  if (s.role === 'nurse' || s.role === 'doctor') hospitalId = s.hospitalId;
  const rows = hospitalId
    ? db.prepare('SELECT * FROM diseases WHERE hospitalId=?').all(hospitalId)
    : db.prepare('SELECT * FROM diseases').all();
  res.json(rows);
});
app.post('/api/diseases', auth, requireRole('admin'), (req, res) => {
  const { hospitalId, name, notes } = req.body;
  if (!hospitalId || !name) return res.status(400).json({ error: 'Hospital and disease name are required' });
  const id = 'DIS-' + Date.now();
  db.prepare('INSERT INTO diseases (id,hospitalId,name,notes) VALUES (?,?,?,?)').run(id, hospitalId, name, notes || '');
  broadcast('diseases:changed', {});
  res.json({ id });
});
app.delete('/api/diseases/:id', auth, requireRole('admin'), (req, res) => {
  db.prepare('DELETE FROM diseases WHERE id=?').run(req.params.id);
  broadcast('diseases:changed', {});
  res.json({ ok: true });
});

/* ================= HEALTH ================= */
app.get('/api/health', (req, res) => res.json({ ok: true, time: new Date().toISOString() }));

io.on('connection', (socket) => {
  socket.on('disconnect', () => {});
});

const PORT = process.env.PORT || 4000;
server.listen(PORT, () => console.log(`Medi+ Command backend running on http://localhost:${PORT}`));
