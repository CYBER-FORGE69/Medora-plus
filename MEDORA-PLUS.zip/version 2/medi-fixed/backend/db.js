const Database = require('better-sqlite3');
const path = require('path');
const bcrypt = require('bcryptjs');

const db = new Database(path.join(__dirname, 'medi-plus.db'));
db.pragma('journal_mode = WAL');

// Passwords are stored as bcrypt hashes, never plaintext. Seed data below is
// hashed at insert time; server.js hashes on every account create/update.
function hashPassword(plain) {
  return bcrypt.hashSync(plain, 10);
}

db.exec(`
CREATE TABLE IF NOT EXISTS hospitals (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  city TEXT,
  address TEXT,
  latitude REAL,
  longitude REAL
);

CREATE TABLE IF NOT EXISTS admins (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  password TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS doctors (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  hospitalId TEXT NOT NULL,
  password TEXT NOT NULL,
  specialty TEXT
);

CREATE TABLE IF NOT EXISTS nurses (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  hospitalId TEXT NOT NULL,
  password TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS patients (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  age INTEGER,
  dept TEXT,
  diagnosis TEXT,
  status TEXT DEFAULT 'stable',
  hospitalId TEXT NOT NULL,
  doctorId TEXT,
  password TEXT NOT NULL,
  insurance TEXT,
  cost REAL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS equipment (
  id TEXT PRIMARY KEY,
  hospitalId TEXT NOT NULL,
  name TEXT NOT NULL,
  total INTEGER DEFAULT 0,
  available INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS beds (
  hospitalId TEXT PRIMARY KEY,
  total INTEGER DEFAULT 0,
  occupied INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS blood_bank (
  id TEXT PRIMARY KEY,
  hospitalId TEXT NOT NULL,
  bloodGroup TEXT NOT NULL,
  units INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS organ_bank (
  id TEXT PRIMARY KEY,
  hospitalId TEXT NOT NULL,
  organ TEXT NOT NULL,
  required INTEGER DEFAULT 0,
  pledged INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS appointments (
  id TEXT PRIMARY KEY,
  patientId TEXT NOT NULL,
  doctorId TEXT,
  hospitalId TEXT NOT NULL,
  date TEXT NOT NULL,
  reason TEXT,
  status TEXT DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS notifications (
  id TEXT PRIMARY KEY,
  audience TEXT NOT NULL,          -- 'admin' | 'doctor:<id>' | 'nurse:<id>' | 'patient:<id>' | 'hospital:<id>'
  message TEXT NOT NULL,
  createdAt TEXT NOT NULL,
  read INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS sos_alerts (
  id TEXT PRIMARY KEY,
  name TEXT,
  phone TEXT,
  reason TEXT,
  hospitalId TEXT,
  latitude REAL,
  longitude REAL,
  createdAt TEXT NOT NULL,
  status TEXT DEFAULT 'open'
);

-- Doctor writes, patient reads: freeform progress notes on a patient's chart.
-- Only the doctor who owns the patient may add/remove entries (enforced in server.js).
CREATE TABLE IF NOT EXISTS health_records (
  id TEXT PRIMARY KEY,
  patientId TEXT NOT NULL,
  doctorId TEXT NOT NULL,
  note TEXT NOT NULL,
  createdAt TEXT NOT NULL
);

-- One diet plan per patient, editable only by their assigned doctor.
CREATE TABLE IF NOT EXISTS diet_plans (
  patientId TEXT PRIMARY KEY,
  doctorId TEXT NOT NULL,
  text TEXT,
  updatedAt TEXT
);

-- Prescribed medicines, editable only by the doctor who prescribed them.
CREATE TABLE IF NOT EXISTS medicines (
  id TEXT PRIMARY KEY,
  patientId TEXT NOT NULL,
  doctorId TEXT NOT NULL,
  name TEXT NOT NULL,
  dosage TEXT,
  instructions TEXT,
  createdAt TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS ambulances (
  id TEXT PRIMARY KEY,
  hospitalId TEXT NOT NULL,
  vehicleNo TEXT NOT NULL,
  driverName TEXT,
  contact TEXT,
  status TEXT DEFAULT 'available'  -- 'available' | 'on-duty'
);

CREATE TABLE IF NOT EXISTS diseases (
  id TEXT PRIMARY KEY,
  hospitalId TEXT NOT NULL,
  name TEXT NOT NULL,
  notes TEXT
);

-- Patient blood-donation intake: vitals captured at screening, plus the
-- appointment date/time for the donation itself. bloodGroup is mandatory.
CREATE TABLE IF NOT EXISTS blood_donations (
  id TEXT PRIMARY KEY,
  patientId TEXT NOT NULL,
  hospitalId TEXT NOT NULL,
  fullName TEXT NOT NULL,
  age INTEGER NOT NULL,
  weight REAL,
  hemoglobin TEXT,
  bloodPressure TEXT,
  pulseRate TEXT,
  bloodGroup TEXT NOT NULL,
  reportImage TEXT,
  appointmentDate TEXT NOT NULL,
  appointmentTime TEXT NOT NULL,
  status TEXT DEFAULT 'pending', -- pending | approved | completed | rejected
  notes TEXT,
  createdAt TEXT NOT NULL
);

-- Nurse-managed medicine reminder schedule for a discharged/post-op patient.
-- "times" is a JSON array of HH:MM strings the patient should be reminded at.
CREATE TABLE IF NOT EXISTS medicine_alarms (
  id TEXT PRIMARY KEY,
  patientId TEXT NOT NULL,
  nurseId TEXT NOT NULL,
  hospitalId TEXT NOT NULL,
  medicineName TEXT NOT NULL,
  times TEXT NOT NULL,
  startDate TEXT,
  endDate TEXT,
  notes TEXT,
  active INTEGER DEFAULT 1,
  createdAt TEXT NOT NULL
);

-- Doctor prescriptions: free-text and/or up to a few photographed pages.
-- When photos are supplied, extractedText holds the AI-read, cleaned-up
-- medicine list the patient sees (see server.js analyzePrescriptionPhotos).
CREATE TABLE IF NOT EXISTS prescriptions (
  id TEXT PRIMARY KEY,
  patientId TEXT NOT NULL,
  doctorId TEXT NOT NULL,
  text TEXT,
  photos TEXT,
  extractedText TEXT,
  createdAt TEXT NOT NULL
);

-- One-time codes for phone/email OTP login and password-reset flows.
-- target = phone number or email the code was sent to; purpose keeps the
-- three flows (login, register, reset) from being interchangeable; codeHash
-- is bcrypt-hashed like passwords, never stored in the clear.
CREATE TABLE IF NOT EXISTS otps (
  id TEXT PRIMARY KEY,
  target TEXT NOT NULL,
  purpose TEXT NOT NULL,
  codeHash TEXT NOT NULL,
  role TEXT,
  attempts INTEGER DEFAULT 0,
  expiresAt TEXT NOT NULL,
  createdAt TEXT NOT NULL
);
`);

// ---- migrations: additive columns for older DB files ----
function ensureColumn(table, column, ddl) {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all().map(c => c.name);
  if (!cols.includes(column)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${ddl}`);
}
ensureColumn('patients', 'phone', 'phone TEXT');
ensureColumn('patients', 'report', 'report TEXT');
ensureColumn('patients', 'isDonor', 'isDonor INTEGER DEFAULT 0');
ensureColumn('patients', 'gender', 'gender TEXT');
ensureColumn('patients', 'bloodGroup', 'bloodGroup TEXT');
ensureColumn('patients', 'photo', 'photo TEXT');
ensureColumn('patients', 'contactNumber', 'contactNumber TEXT');
ensureColumn('patients', 'emergencyContact', 'emergencyContact TEXT');
ensureColumn('patients', 'address', 'address TEXT');
ensureColumn('admins', 'photo', 'photo TEXT');
ensureColumn('admins', 'address', 'address TEXT');
ensureColumn('doctors', 'photo', 'photo TEXT');
ensureColumn('doctors', 'address', 'address TEXT');
ensureColumn('nurses', 'photo', 'photo TEXT');
ensureColumn('nurses', 'address', 'address TEXT');
// Google Sign-In links a patient by the Google account's stable subject ID;
// email backs both Google linking and the forgot-password flow for staff
// roles, which (unlike patients) have no phone column to send a code to.
ensureColumn('patients', 'googleId', 'googleId TEXT');
ensureColumn('patients', 'email', 'email TEXT');
ensureColumn('admins', 'email', 'email TEXT');
ensureColumn('doctors', 'email', 'email TEXT');
ensureColumn('nurses', 'email', 'email TEXT');
// "Quick SOS" — a patient's own trusted ambulance contact, shown and dialed
// straight from their emergency button rather than a hospital-fleet lookup.
ensureColumn('patients', 'preferredAmbulanceName', 'preferredAmbulanceName TEXT');
ensureColumn('patients', 'preferredAmbulanceContact', 'preferredAmbulanceContact TEXT');
ensureColumn('sos_alerts', 'ambulanceContact', 'ambulanceContact TEXT');
ensureColumn('sos_alerts', 'ambulanceName', 'ambulanceName TEXT');

function seedIfEmpty() {
  const count = db.prepare('SELECT COUNT(*) c FROM hospitals').get().c;
  if (count > 0) return;

  const insHosp = db.prepare('INSERT INTO hospitals (id,name,city,address,latitude,longitude) VALUES (?,?,?,?,?,?)');
  insHosp.run('H-1', 'Metro General Hospital', 'Nagpur', 'Civil Lines, Nagpur, Maharashtra', 21.1498, 79.0821);
  insHosp.run('H-2', 'Riverside Medical Center', 'Nagpur', 'Sitabuldi, Nagpur, Maharashtra', 21.1466, 79.0882);

  db.prepare('INSERT INTO admins (id,name,password) VALUES (?,?,?)')
    .run('ADM-1001', 'Hospital Admin', hashPassword('admin123'));

  const insDoc = db.prepare('INSERT INTO doctors (id,name,hospitalId,password,specialty) VALUES (?,?,?,?,?)');
  insDoc.run('DR-1001', 'Dr. Asha Verma', 'H-1', hashPassword('doc123'), 'Cardiology');
  insDoc.run('DR-1002', 'Dr. Karan Mehta', 'H-2', hashPassword('doc123'), 'Orthopedics');

  const insNur = db.prepare('INSERT INTO nurses (id,name,hospitalId,password) VALUES (?,?,?,?)');
  insNur.run('NR-1001', 'Nurse Priya Rao', 'H-1', hashPassword('nurse123'));

  const insPat = db.prepare(`INSERT INTO patients (id,name,age,dept,diagnosis,status,hospitalId,doctorId,password,insurance,cost,gender,bloodGroup,contactNumber,emergencyContact)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  insPat.run('PT-001', 'Rohan Sharma', 34, 'Cardiology', 'Hypertension', 'stable', 'H-1', 'DR-1001', hashPassword('pat123'), 'StarHealth', 12500, 'Male', 'B+', '9820012345', 'Sunita Sharma: 9820098765');
  insPat.run('PT-002', 'Meera Iyer', 58, 'Orthopedics', 'Fracture - left tibia', 'moderate', 'H-2', 'DR-1002', hashPassword('pat123'), 'ICICI Lombard', 34000, 'Female', 'O+', '9765043210', 'Anand Iyer: 9765011111');

  const insEq = db.prepare('INSERT INTO equipment (id,hospitalId,name,total,available) VALUES (?,?,?,?,?)');
  insEq.run('EQ-1', 'H-1', 'Ventilators', 20, 14);
  insEq.run('EQ-2', 'H-1', 'ICU Monitors', 30, 22);
  insEq.run('EQ-3', 'H-2', 'Ventilators', 15, 9);

  db.prepare('INSERT INTO beds (hospitalId,total,occupied) VALUES (?,?,?)').run('H-1', 120, 87);
  db.prepare('INSERT INTO beds (hospitalId,total,occupied) VALUES (?,?,?)').run('H-2', 90, 41);

  const insBlood = db.prepare('INSERT INTO blood_bank (id,hospitalId,bloodGroup,units) VALUES (?,?,?,?)');
  const groups = ['A+','A-','B+','B-','AB+','AB-','O+','O-'];
  const startsH1 = [12,4,9,3,6,2,20,7];
  const startsH2 = [8,2,6,1,3,1,14,4];
  groups.forEach((g,i) => insBlood.run(`BB-H1-${g}`, 'H-1', g, startsH1[i]));
  groups.forEach((g,i) => insBlood.run(`BB-H2-${g}`, 'H-2', g, startsH2[i]));

  const insOrgan = db.prepare('INSERT INTO organ_bank (id,hospitalId,organ,required,pledged) VALUES (?,?,?,?,?)');
  const organs = ['Kidney','Liver','Heart','Lungs','Cornea','Pancreas'];
  const reqH1 = [5, 3, 2, 2, 6, 1];
  const pledgedH1 = [2, 1, 0, 1, 4, 0];
  const reqH2 = [3, 2, 1, 1, 4, 1];
  const pledgedH2 = [1, 0, 0, 0, 2, 0];
  organs.forEach((o,i) => insOrgan.run(`OB-H1-${o}`, 'H-1', o, reqH1[i], pledgedH1[i]));
  organs.forEach((o,i) => insOrgan.run(`OB-H2-${o}`, 'H-2', o, reqH2[i], pledgedH2[i]));

  const insAmb = db.prepare('INSERT INTO ambulances (id,hospitalId,vehicleNo,driverName,contact,status) VALUES (?,?,?,?,?,?)');
  insAmb.run('AMB-1', 'H-1', 'MH-31-AB-1234', 'Suresh Pawar', '9822011111', 'available');
  insAmb.run('AMB-2', 'H-1', 'MH-31-AB-5678', 'Ramesh Kale', '9822022222', 'on-duty');
  insAmb.run('AMB-3', 'H-2', 'MH-31-CD-4321', 'Vikas Deshmukh', '9822033333', 'available');

  const insDis = db.prepare('INSERT INTO diseases (id,hospitalId,name,notes) VALUES (?,?,?,?)');
  insDis.run('DIS-1', 'H-1', 'Hypertension', 'Common in cardiology ward, monitored with routine BP checks.');
  insDis.run('DIS-2', 'H-1', 'Type 2 Diabetes', 'Managed via diet plans and periodic glucose monitoring.');
  insDis.run('DIS-3', 'H-2', 'Fractures', 'Most frequent in orthopedics; average recovery tracked per case.');
}
seedIfEmpty();

// Migration: existing DBs (created before organ donation tracking existed) already
// have hospitals seeded, so seedIfEmpty() above is a no-op for them — backfill
// organ_bank rows for any hospital that doesn't have them yet.
function backfillOrganBank() {
  const organs = ['Kidney','Liver','Heart','Lungs','Cornea','Pancreas'];
  const hospitalsList = db.prepare('SELECT id FROM hospitals').all();
  for (const h of hospitalsList) {
    const has = db.prepare('SELECT COUNT(*) c FROM organ_bank WHERE hospitalId=?').get(h.id).c;
    if (has > 0) continue;
    const ins = db.prepare('INSERT INTO organ_bank (id,hospitalId,organ,required,pledged) VALUES (?,?,?,0,0)');
    organs.forEach(o => ins.run(`OB-${h.id}-${o}`, h.id, o));
  }
}
backfillOrganBank();

// One-time migration: any password already stored as plaintext (i.e. not a
// bcrypt hash, which always starts with "$2") gets hashed in place. This lets
// existing/older DB files upgrade automatically instead of locking users out.
function migratePlaintextPasswords() {
  const isHash = (p) => typeof p === 'string' && /^\$2[aby]?\$/.test(p);
  for (const table of ['admins', 'doctors', 'nurses', 'patients']) {
    const rows = db.prepare(`SELECT id, password FROM ${table}`).all();
    const upd = db.prepare(`UPDATE ${table} SET password=? WHERE id=?`);
    for (const row of rows) {
      if (row.password && !isHash(row.password)) upd.run(hashPassword(row.password), row.id);
    }
  }
}
migratePlaintextPasswords();

/* ---------------- field-level encryption at rest ----------------
 * Sensitive payloads (donor vitals, prescription text/photos) are encrypted
 * with AES-256-GCM before they're written to the database, and decrypted
 * only for callers who already passed the route's own access checks.
 * NOTE ON SCOPE: this protects the data on disk (DB file, backups) — it is
 * NOT full client-held-key end-to-end encryption, which would need the
 * browser itself to hold the key and would break server-side features like
 * search/notifications. Set ENCRYPTION_KEY (32-byte hex) in production; a
 * random key is generated per boot otherwise, which is fine for local/dev
 * use but means data can't be decrypted across restarts.
 */
const crypto = require('crypto');
const ENC_KEY = (() => {
  const fromEnv = process.env.ENCRYPTION_KEY;
  if (fromEnv && /^[0-9a-f]{64}$/i.test(fromEnv)) return Buffer.from(fromEnv, 'hex');
  if (fromEnv) console.warn('[encryption] ENCRYPTION_KEY is set but is not 64 hex chars (32 bytes) — ignoring it and generating a temporary key.');
  console.warn('[encryption] No ENCRYPTION_KEY set — using a random per-boot key. Set ENCRYPTION_KEY (32-byte hex) in production so data survives restarts.');
  return crypto.randomBytes(32);
})();
function encryptField(plain) {
  if (plain === null || plain === undefined || plain === '') return plain;
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', ENC_KEY, iv);
  const enc = Buffer.concat([cipher.update(String(plain), 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return 'enc:' + Buffer.concat([iv, tag, enc]).toString('base64');
}
function decryptField(stored) {
  if (stored === null || stored === undefined || stored === '') return stored;
  if (typeof stored !== 'string' || !stored.startsWith('enc:')) return stored; // not encrypted (e.g. pre-migration row)
  try {
    const buf = Buffer.from(stored.slice(4), 'base64');
    const iv = buf.subarray(0, 12), tag = buf.subarray(12, 28), data = buf.subarray(28);
    const decipher = crypto.createDecipheriv('aes-256-gcm', ENC_KEY, iv);
    decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(data), decipher.final()]).toString('utf8');
  } catch (e) {
    return '[unreadable — encrypted with a different key]';
  }
}

module.exports = db;
module.exports.hashPassword = hashPassword;
module.exports.encryptField = encryptField;
module.exports.decryptField = decryptField;
module.exports.verifyPassword = (plain, hashOrPlain) => {
  if (typeof hashOrPlain !== 'string') return false;
  if (/^\$2[aby]?\$/.test(hashOrPlain)) return bcrypt.compareSync(plain, hashOrPlain);
  // Defensive fallback in case migration hasn't run for some reason yet.
  return plain === hashOrPlain;
};
