// Medi+ split-role login controller
const BASE_HOST = (window.location.protocol === 'file:' || !window.location.port || window.location.port !== '4000') ? 'http://localhost:4000' : '';
const API = BASE_HOST + '/api';
let session = null;
let socket = null;
let hospitals = [];
let currentView = 'overview';
let detectedCoords = null;


/* ---------------- Auth & Role Switching ---------------- */
let selectedRole = 'patient';
const roleLabels = { patient: 'Patient', doctor: 'Doctor', nurse: 'Nurse', admin: 'Hospital Admin' };

document.querySelectorAll('.role-tab').forEach(btn => {
  btn.addEventListener('click', () => {
    switchRoleTab(btn.dataset.role);
  });
});

function switchRoleTab(role) {
  selectedRole = role;
  document.querySelectorAll('.role-tab').forEach(b => b.classList.toggle('active', b.dataset.role === role));
  document.getElementById('patientFields').classList.toggle('hidden', selectedRole !== 'patient');
  document.getElementById('staffFields').classList.toggle('hidden', selectedRole === 'patient');
  document.getElementById('loginSubmitBtn').textContent = 'Sign In as ' + roleLabels[selectedRole];
  document.getElementById('loginErr').classList.remove('show');
}

/* ---------------- Google Sign-In ---------------- */
// 1) Create an OAuth 2.0 "Web application" Client ID at
//    https://console.cloud.google.com/apis/credentials, add this app's
//    URL under "Authorized JavaScript origins", then paste the Client ID below.
const GOOGLE_CLIENT_ID = '994133068541-m9qjtguadi07333n8g5secfdhh7outal.apps.googleusercontent.com';

function initGoogleSignIn() {
  if (!window.google || !google.accounts || !google.accounts.id) return;
  if (GOOGLE_CLIENT_ID.startsWith('YOUR_GOOGLE_CLIENT_ID')) {
    console.warn('Google Sign-In: set GOOGLE_CLIENT_ID near the top of frontend/login.js to enable it.');
    return;
  }
  google.accounts.id.initialize({
    client_id: GOOGLE_CLIENT_ID,
    callback: handleGoogleCredential,
    auto_select: true,          // silently sign back in if this browser already has an active Google session
    cancel_on_tap_outside: false
  });
  // One Tap: if the user is already logged in to Google, this detects it and
  // signs them in automatically without an extra click.
  google.accounts.id.prompt();
}

function parseJwt(token) {
  try {
    const payload = token.split('.')[1];
    return JSON.parse(decodeURIComponent(atob(payload.replace(/-/g, '+').replace(/_/g, '/'))
      .split('').map(c => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2)).join('')));
  } catch (e) { return null; }
}

async function handleGoogleCredential(response) {
  // The ID token is sent to the backend, which verifies its signature and
  // audience with Google directly (never trust a client-side JWT parse for
  // auth decisions), then finds-or-creates the matching patient account.
  const errBox = document.getElementById('loginErr');
  errBox.classList.remove('show');
  const btn = document.getElementById('googleLoginBtn');
  const label = document.getElementById('googleBtnLabel');
  const prevLabel = label ? label.textContent : '';
  if (label) label.textContent = 'Signing in...';
  try {
    const r = await fetch(`${API}/auth/google`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ credential: response.credential })
    });
    const data = await r.json();
    if (!r.ok) {
      errBox.textContent = data.error || 'Google sign-in failed.';
      errBox.classList.add('show');
      return;
    }
    session = { token: data.token, role: data.role, user: data.user };
    await saveSessionAndRedirect();
  } catch (err) {
    errBox.textContent = 'Cannot reach backend at ' + API + ' — verify server is running.';
    errBox.classList.add('show');
  } finally {
    if (label) label.textContent = prevLabel;
  }
}

function googleLogin() {
  if (!window.google || !google.accounts || !google.accounts.id) {
    document.getElementById('loginErr').textContent = 'Google Sign-In is still loading — please try again in a second.';
    document.getElementById('loginErr').classList.add('show');
    return;
  }
  if (GOOGLE_CLIENT_ID.startsWith('YOUR_GOOGLE_CLIENT_ID')) {
    document.getElementById('loginErr').textContent = 'Google Sign-In needs a Client ID — set GOOGLE_CLIENT_ID near the top of frontend/login.js.';
    document.getElementById('loginErr').classList.add('show');
    return;
  }
  google.accounts.id.prompt();
}

window.addEventListener('load', initGoogleSignIn);

// 1-Click Direct Demo Login
async function directLogin(role, id, secret) {
  switchRoleTab(role);
  if (role === 'patient') {
    document.getElementById('patId').value = id;
    document.getElementById('patSecret').value = secret;
  } else {
    document.getElementById('loginId').value = id;
    document.getElementById('loginPw').value = secret;
  }
  await performLogin(role, id, secret);
}

document.getElementById('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errBox = document.getElementById('loginErr');
  errBox.classList.remove('show');

  if (selectedRole === 'patient') {
    const identifier = document.getElementById('patId').value.trim();
    const secret = document.getElementById('patSecret').value.trim();

    if (!secret) {
      errBox.textContent = 'Password or phone number is required';
      errBox.classList.add('show');
      return;
    }

    if (!identifier) {
      // Register new patient flow
      try {
        const r = await fetch(`${API}/patients/self-register`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: 'New Patient', phone: secret })
        });
        const data = await r.json();
        if (!r.ok) { errBox.textContent = data.error || 'Registration failed'; errBox.classList.add('show'); return; }
        session = { token: data.token, role: 'patient', user: data.user };
        saveSessionAndRedirect();
      } catch (err) {
        errBox.textContent = 'Cannot reach backend at ' + API + ' — verify server is running.';
        errBox.classList.add('show');
      }
    } else {
      await performLogin('patient', identifier, secret);
    }
  } else {
    const id = document.getElementById('loginId').value.trim();
    const password = document.getElementById('loginPw').value;
    if (!id || !password) {
      errBox.textContent = 'Please enter your ID/name and password';
      errBox.classList.add('show');
      return;
    }
    await performLogin(selectedRole, id, password);
  }
});

async function saveSessionAndRedirect() {
  localStorage.setItem('mediPlusSession', JSON.stringify(session));
  const target = `${session.role}.html`;
  window.location.href = target;
}

async function performLogin(role, id, password) {
  const errBox = document.getElementById('loginErr');
  const btn = document.getElementById('loginSubmitBtn');
  errBox.classList.remove('show');
  btn.textContent = 'Authenticating...';
  try {
    const r = await fetch(`${API}/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ role, id, password })
    });
    const data = await r.json();
    if (!r.ok) {
      errBox.textContent = data.error || 'Invalid credentials. Please check ID and password.';
      errBox.classList.add('show');
      return;
    }
    session = { token: data.token, role: data.role, user: data.user };
    await saveSessionAndRedirect();
  } catch (err) {
    errBox.textContent = 'Cannot reach backend at ' + API + ' — verify server is running on port 4000.';
    errBox.classList.add('show');
  } finally {
    btn.textContent = 'Sign In as ' + roleLabels[selectedRole];
  }
}

/* ---------------- Phone OTP Login ---------------- */
function openOtpLogin() {
  document.getElementById('otpOverlay').classList.remove('hidden');
  document.getElementById('otpErr').classList.remove('show');
  document.getElementById('otpPhone').value = document.getElementById('patSecret').value.match(/^\d{6,}$/) ? document.getElementById('patSecret').value : '';
  backToOtpPhone();
}
function closeOtpLogin() { document.getElementById('otpOverlay').classList.add('hidden'); }
function backToOtpPhone() {
  document.getElementById('otpStepPhone').classList.remove('hidden');
  document.getElementById('otpStepCode').classList.add('hidden');
  document.getElementById('otpErr').classList.remove('show');
}

async function requestLoginOtp() {
  const errBox = document.getElementById('otpErr');
  errBox.classList.remove('show');
  const phone = document.getElementById('otpPhone').value.trim();
  if (!phone) { errBox.textContent = 'Enter a phone number first'; errBox.classList.add('show'); return; }
  const btn = document.getElementById('otpRequestBtn');
  btn.textContent = 'Sending...';
  try {
    const r = await fetch(`${API}/auth/otp/request`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone })
    });
    const data = await r.json();
    if (!r.ok) { errBox.textContent = data.error || 'Could not send OTP'; errBox.classList.add('show'); return; }
    document.getElementById('otpStepPhone').classList.add('hidden');
    document.getElementById('otpStepCode').classList.remove('hidden');
    errBox.textContent = 'Code sent to ' + data.sentTo + (data.devOtp ? ` (dev mode — code: ${data.devOtp})` : '');
    errBox.classList.add('show');
  } catch (err) {
    errBox.textContent = 'Cannot reach backend at ' + API + ' — verify server is running.';
    errBox.classList.add('show');
  } finally {
    btn.textContent = 'Send OTP';
  }
}

async function verifyLoginOtp() {
  const errBox = document.getElementById('otpErr');
  errBox.classList.remove('show');
  const phone = document.getElementById('otpPhone').value.trim();
  const otp = document.getElementById('otpCode').value.trim();
  const name = document.getElementById('otpName').value.trim();
  if (!otp) { errBox.textContent = 'Enter the OTP you received'; errBox.classList.add('show'); return; }
  const btn = document.getElementById('otpVerifyBtn');
  btn.textContent = 'Verifying...';
  try {
    const r = await fetch(`${API}/auth/otp/verify`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone, otp, name })
    });
    const data = await r.json();
    if (!r.ok) { errBox.textContent = data.error || 'Invalid OTP'; errBox.classList.add('show'); return; }
    session = { token: data.token, role: data.role, user: data.user };
    await saveSessionAndRedirect();
  } catch (err) {
    errBox.textContent = 'Cannot reach backend at ' + API + ' — verify server is running.';
    errBox.classList.add('show');
  } finally {
    btn.textContent = 'Verify & Sign In';
  }
}

/* ---------------- Forgot Password ---------------- */
function openForgotPassword() {
  document.getElementById('forgotOverlay').classList.remove('hidden');
  document.getElementById('forgotErr').classList.remove('show');
  document.getElementById('forgotRole').value = selectedRole;
  document.getElementById('forgotStepId').classList.remove('hidden');
  document.getElementById('forgotStepReset').classList.add('hidden');
}
function closeForgotPassword() { document.getElementById('forgotOverlay').classList.add('hidden'); }

async function requestPasswordReset() {
  const errBox = document.getElementById('forgotErr');
  errBox.classList.remove('show');
  const role = document.getElementById('forgotRole').value;
  const id = document.getElementById('forgotId').value.trim();
  if (!id) { errBox.textContent = 'Enter your account ID or full name'; errBox.classList.add('show'); return; }
  const btn = document.getElementById('forgotRequestBtn');
  btn.textContent = 'Sending...';
  try {
    const r = await fetch(`${API}/auth/password/forgot/request`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ role, id })
    });
    const data = await r.json();
    if (!r.ok) { errBox.textContent = data.error || 'Could not send reset code'; errBox.classList.add('show'); return; }
    document.getElementById('forgotStepId').classList.add('hidden');
    document.getElementById('forgotStepReset').classList.remove('hidden');
    errBox.textContent = data.sentTo
      ? 'Reset code sent to ' + data.sentTo + (data.devOtp ? ` (dev mode — code: ${data.devOtp})` : '')
      : data.message;
    errBox.classList.add('show');
  } catch (err) {
    errBox.textContent = 'Cannot reach backend at ' + API + ' — verify server is running.';
    errBox.classList.add('show');
  } finally {
    btn.textContent = 'Send Reset Code';
  }
}

async function submitPasswordReset() {
  const errBox = document.getElementById('forgotErr');
  errBox.classList.remove('show');
  const role = document.getElementById('forgotRole').value;
  const id = document.getElementById('forgotId').value.trim();
  const otp = document.getElementById('forgotOtp').value.trim();
  const newPassword = document.getElementById('forgotNewPw').value;
  if (!otp || !newPassword) { errBox.textContent = 'Enter the reset code and a new password'; errBox.classList.add('show'); return; }
  const btn = document.getElementById('forgotResetBtn');
  btn.textContent = 'Saving...';
  try {
    const r = await fetch(`${API}/auth/password/forgot/verify`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ role, id, otp, newPassword })
    });
    const data = await r.json();
    if (!r.ok) { errBox.textContent = data.error || 'Could not reset password'; errBox.classList.add('show'); return; }
    errBox.textContent = 'Password updated — you can sign in now.';
    errBox.classList.add('show');
    setTimeout(closeForgotPassword, 1500);
  } catch (err) {
    errBox.textContent = 'Cannot reach backend at ' + API + ' — verify server is running.';
    errBox.classList.add('show');
  } finally {
    btn.textContent = 'Set New Password';
  }
}

/* ---------------- SOS Emergency ---------------- */
async function openSos() {
  document.getElementById('sosOverlay').classList.remove('hidden');
  document.getElementById('sosErr').classList.remove('show');
  document.getElementById('sosFormWrap').classList.remove('hidden');
  document.getElementById('sosSent').classList.add('hidden');
  document.getElementById('sosForm').reset();
  
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        detectedCoords = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        document.getElementById('gpsText').textContent = `GPS Location: ${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)}`;
      },
      () => {
        document.getElementById('gpsText').textContent = 'Location optional (IP approximation active).';
      },
      { timeout: 4000 }
    );
  }

  try {
    const hosps = await fetch(`${API}/hospitals/public`).then(r => r.json());
    document.getElementById('sosHospital').innerHTML = (hosps || []).map(h => `<option value="${h.id}">${h.name}${h.city ? ' — ' + h.city : ''}</option>`).join('');
  } catch (e) {}
}

function closeSos() { document.getElementById('sosOverlay').classList.add('hidden'); }

document.getElementById('sosForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errBox = document.getElementById('sosErr');
  errBox.classList.remove('show');
  const payload = {
    name: document.getElementById('sosName').value.trim(),
    phone: document.getElementById('sosPhone').value.trim(),
    hospitalId: document.getElementById('sosHospital').value,
    reason: document.getElementById('sosReason').value.trim(),
    ...(detectedCoords ? { latitude: detectedCoords.lat, longitude: detectedCoords.lng } : {})
  };
  try {
    const r = await fetch(`${API}/sos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await r.json();
    if (!r.ok) { errBox.textContent = data.error || 'Could not send SOS'; errBox.classList.add('show'); return; }
    document.getElementById('sosFormWrap').classList.add('hidden');
    document.getElementById('sosSent').classList.remove('hidden');
  } catch (err) {
    errBox.textContent = 'Cannot reach backend — is the server running?';
    errBox.classList.add('show');
  }
});

