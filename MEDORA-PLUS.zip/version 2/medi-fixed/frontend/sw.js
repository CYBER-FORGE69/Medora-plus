// Medi+ Command service worker.
// Purpose: (1) satisfies the installability requirement most browsers have
// (a fetch handler must be registered), (2) caches the static app shell
// (HTML/CSS/JS/icons) so the app still opens with a spinner-free shell if
// the network briefly drops, (3) NEVER caches /api/ or socket.io calls —
// those must always hit the live backend, never stale data.
const CACHE_NAME = 'mediplus-shell-v1';
const SHELL_FILES = [
  '/', '/index.html', '/admin.html', '/doctor.html', '/nurse.html', '/patient.html',
  '/common.css', '/app.js', '/login.js', '/manifest.json',
  '/icons/icon-192.png', '/icons/icon-512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL_FILES)).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((names) =>
      Promise.all(names.filter((n) => n !== CACHE_NAME).map((n) => caches.delete(n)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Never intercept API calls or the Socket.IO connection — always live.
  if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/socket.io/')) return;
  if (event.request.method !== 'GET') return;

  // App shell: cache-first, falling back to network, so the app opens
  // instantly and still works if the WiFi hiccups.
  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request).then((res) => {
        if (res && res.ok && url.origin === self.location.origin) {
          const copy = res.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
        }
        return res;
      }).catch(() => cached);
    })
  );
});
